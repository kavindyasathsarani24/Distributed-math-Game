@echo off
echo Building Banana Dash Game...

:: Create build directory
if not exist build mkdir build

:: Create lib directory if it doesn't exist
if not exist lib mkdir lib

:: Download required libraries if they don't exist
if not exist lib\sqlite-jdbc-3.41.2.2.jar (
    echo Downloading SQLite JDBC Driver...
    powershell -Command "Invoke-WebRequest -Uri 'https://repo1.maven.org/maven2/org/xerial/sqlite-jdbc/3.41.2.2/sqlite-jdbc-3.41.2.2.jar' -OutFile 'lib\sqlite-jdbc-3.41.2.2.jar'"
)

if not exist lib\httpclient-4.5.14.jar (
    echo Downloading Apache HttpClient...
    powershell -Command "Invoke-WebRequest -Uri 'https://repo1.maven.org/maven2/org/apache/httpcomponents/httpclient/4.5.14/httpclient-4.5.14.jar' -OutFile 'lib\httpclient-4.5.14.jar'"
)

if not exist lib\httpcore-4.4.16.jar (
    echo Downloading Apache HttpCore...
    powershell -Command "Invoke-WebRequest -Uri 'https://repo1.maven.org/maven2/org/apache/httpcomponents/httpcore/4.4.16/httpcore-4.4.16.jar' -OutFile 'lib\httpcore-4.4.16.jar'"
)

if not exist lib\json-20230227.jar (
    echo Downloading JSON Library...
    powershell -Command "Invoke-WebRequest -Uri 'https://repo1.maven.org/maven2/org/json/json/20230227/json-20230227.jar' -OutFile 'lib\json-20230227.jar'"
)

if not exist lib\commons-logging-1.2.jar (
    echo Downloading Commons Logging...
    powershell -Command "Invoke-WebRequest -Uri 'https://repo1.maven.org/maven2/commons-logging/commons-logging/1.2/commons-logging-1.2.jar' -OutFile 'lib\commons-logging-1.2.jar'"
)

if not exist lib\commons-codec-1.11.jar (
    echo Downloading Commons Codec...
    powershell -Command "Invoke-WebRequest -Uri 'https://repo1.maven.org/maven2/commons-codec/commons-codec/1.11/commons-codec-1.11.jar' -OutFile 'lib\commons-codec-1.11.jar'"
)

:: Set classpath
set CLASSPATH=build;lib\sqlite-jdbc-3.41.2.2.jar;lib\httpclient-4.5.14.jar;lib\httpcore-4.4.16.jar;lib\json-20230227.jar;lib\commons-logging-1.2.jar;lib\commons-codec-1.11.jar

:: Compile the Java files
echo Compiling Java files...
javac -d build -cp "%CLASSPATH%" src\main\java\com\bananadash\game\utils\*.java src\main\java\com\bananadash\game\model\*.java src\main\java\com\bananadash\game\view\*.java src\main\java\com\bananadash\game\controller\*.java src\main\java\com\bananadash\game\*.java

:: Create database directory if it doesn't exist
if not exist database mkdir database

:: Copy resources
echo Copying resources...
if not exist build\resources mkdir build\resources
if not exist build\resources\images mkdir build\resources\images
if exist src\main\resources\images\*.* (
    copy src\main\resources\images\*.* build\resources\images\
)

:: Run the game
echo Running Banana Dash Game...
java -cp "%CLASSPATH%" com.bananadash.game.Main

echo Done!
pause 