# Banana Dash Game

Banana Dash is a puzzle game where players solve visual puzzles against a timer. The game features user authentication, profile management, and progressive difficulty levels.

## Features

- User registration and login system
- Profile management with statistics tracking
- Leaderboard to compare scores with other players
- Progressive difficulty levels with decreasing time limits
- Puzzle-based gameplay using the Banana API
- Scoring system with time bonuses and streak bonuses

## Requirements

- Java Development Kit (JDK) 8 or higher
- Internet connection (for puzzle API)

## Libraries Used

- SQLite JDBC Driver (sqlite-jdbc-3.41.2.2.jar)
- Apache HttpClient (httpclient-4.5.14.jar)
- Apache HttpCore (httpcore-4.4.16.jar)
- JSON Library (json-20230227.jar)
- Commons Logging (commons-logging-1.2.jar)
- Commons Codec (commons-codec-1.11.jar)

## How to Run

1. Clone or download this repository
2. Run the `build_and_run.bat` script (Windows)
   - This will download the required libraries, compile the code, and run the game
3. For manual compilation:
   ```
   javac -d build -cp "lib/*" src/main/java/com/bananadash/game/**/*.java
   java -cp "build;lib/*" com.bananadash.game.Main
   ```

## Game Instructions

1. Register a new account or login with existing credentials
2. From the home screen, click "Start Game" to begin
3. Each level presents a puzzle image with a missing number
4. Determine the missing number and enter it in the answer field
5. Submit your answer before the timer runs out
6. Successfully completing a level advances you to the next level with a shorter time limit
7. Your score is based on correct answers, remaining time, and consecutive correct answers

## Project Structure

- `src/main/java/com/bananadash/game/` - Main source code
  - `model/` - Data models and game logic
  - `view/` - UI components
  - `controller/` - Controllers for handling user interactions
  - `utils/` - Utility classes
- `database/` - SQLite database for user data
- `lib/` - External libraries
- `resources/` - Game resources (images, etc.)

## Credits

- Puzzle API provided by [Marc Conrad's Banana API](http://marcconrad.com/uob/banana/api.php)
- Developed as a Java programming exercise

## License

This project is for educational purposes only. 