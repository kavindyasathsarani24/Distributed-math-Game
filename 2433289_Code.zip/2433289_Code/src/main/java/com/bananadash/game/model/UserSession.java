package com.bananadash.game.model;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;


//Represents a user session in the Banana Dash game.

public class UserSession {
    private int userId;
    private String username;
    private LocalDateTime loginTime;
    private LocalDateTime lastActivityTime;
    private boolean active;
    private String sessionId;
    
   
    //Creates a new UserSession instance.
     
    public UserSession(int userId, String username) {
        this.userId = userId;
        this.username = username;
        this.loginTime = LocalDateTime.now();
        this.lastActivityTime = LocalDateTime.now();
        this.active = true;
        this.sessionId = generateSessionId();
    }
    
   
    //Generates a unique session ID.
     
    private String generateSessionId() {
        // Generate a simple session ID based on user ID and timestamp
        return userId + "-" + System.currentTimeMillis();
    }
    
    //Updates the last activity time to the current time.
    
    public void updateActivity() {
        this.lastActivityTime = LocalDateTime.now();
    }
    
    
    //Ends the current session.
     
    public void endSession() {
        this.active = false;
    }
    
   
    //Gets the session duration in minutes.
    
    public long getSessionDurationMinutes() {
        LocalDateTime endTime = active ? LocalDateTime.now() : lastActivityTime;
        return java.time.Duration.between(loginTime, endTime).toMinutes();
    }
    
    
    //Checks if the session is active.
     
    public boolean isActive() {
        return active;
    }
    
    
    //Checks if the session has timed out.
    
    public boolean hasTimedOut(int timeoutMinutes) {
        if (!active) {
            return true;
        }
        
        LocalDateTime now = LocalDateTime.now();
        long inactiveMinutes = java.time.Duration.between(lastActivityTime, now).toMinutes();
        return inactiveMinutes >= timeoutMinutes;
    }
    
    // Set getters
    
    public int getUserId() {
        return userId;
    }
    
    public String getUsername() {
        return username;
    }
    
    public LocalDateTime getLoginTime() {
        return loginTime;
    }
    
    public String getFormattedLoginTime() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        return loginTime.format(formatter);
    }
    
    public LocalDateTime getLastActivityTime() {
        return lastActivityTime;
    }
    
    public String getSessionId() {
        return sessionId;
    }
} 