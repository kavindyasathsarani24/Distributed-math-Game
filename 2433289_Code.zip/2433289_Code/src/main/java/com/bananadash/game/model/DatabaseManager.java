package com.bananadash.game.model;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.json.JSONObject;

/**
Manages database operations for the Banana Dash game.
Handles user authentication, profile management, and leaderboard data.
*/ 
public class DatabaseManager {
    private static final String DB_URL = "jdbc:sqlite:database/game_data.db";
    private Connection connection;
    
    
     //Initializes the database connection and creates tables if they don't exist.
     
    public void initializeDatabase() {
        try {
            // Create a connection to the database
            connection = DriverManager.getConnection(DB_URL);
            System.out.println("Database connection established.");
            
            // Create tables if they don't exist
            createTables();
        } catch (SQLException e) {
            System.err.println("Database initialization error: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    
    //Creates the necessary tables in the database.
   
    private void createTables() throws SQLException {
        Statement statement = connection.createStatement();
        
        // Users table
        statement.execute(
            "CREATE TABLE IF NOT EXISTS Users (" +
            "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
            "username TEXT UNIQUE NOT NULL, " +
            "password_hash TEXT NOT NULL, " +
            "registration_date TEXT DEFAULT CURRENT_TIMESTAMP" +
            ")"
        );
        
        // Profiles table
        statement.execute(
            "CREATE TABLE IF NOT EXISTS Profiles (" +
            "user_id INTEGER PRIMARY KEY, " +
            "display_name TEXT, " +
            "total_score INTEGER DEFAULT 0, " +
            "last_login TEXT DEFAULT CURRENT_TIMESTAMP, " +
            "FOREIGN KEY (user_id) REFERENCES Users(id)" +
            ")"
        );
        
        // Leaderboard table
        statement.execute(
            "CREATE TABLE IF NOT EXISTS Leaderboard (" +
            "user_id INTEGER PRIMARY KEY, " +
            "current_level INTEGER DEFAULT 1, " +
            "highest_level INTEGER DEFAULT 1, " +
            "fastest_times TEXT DEFAULT '{}', " +
            "FOREIGN KEY (user_id) REFERENCES Users(id)" +
            ")"
        );
        
        // Session logs table
        statement.execute(
            "CREATE TABLE IF NOT EXISTS SessionLogs (" +
            "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
            "user_id INTEGER NOT NULL, " +
            "session_id TEXT NOT NULL, " +
            "activity_type TEXT NOT NULL, " +
            "timestamp TEXT DEFAULT CURRENT_TIMESTAMP, " +
            "FOREIGN KEY (user_id) REFERENCES Users(id)" +
            ")"
        );
        
        statement.close();
        System.out.println("Database tables created successfully.");
    }
    
    
    //Registers a new user in the database.
    
    public boolean registerUser(String username, String passwordHash) {
        try {
            // Check if username already exists
            PreparedStatement checkStmt = connection.prepareStatement(
                "SELECT COUNT(*) FROM Users WHERE username = ?"
            );
            checkStmt.setString(1, username);
            ResultSet rs = checkStmt.executeQuery();
            rs.next();
            if (rs.getInt(1) > 0) {
                System.out.println("Username already exists.");
                return false;
            }
            
            // Insert new user
            connection.setAutoCommit(false);
            
            PreparedStatement insertUserStmt = connection.prepareStatement(
                "INSERT INTO Users (username, password_hash) VALUES (?, ?)",
                Statement.RETURN_GENERATED_KEYS
            );
            insertUserStmt.setString(1, username);
            insertUserStmt.setString(2, passwordHash);
            insertUserStmt.executeUpdate();
            
            // Get the generated user ID
            ResultSet generatedKeys = insertUserStmt.getGeneratedKeys();
            if (!generatedKeys.next()) {
                connection.rollback();
                return false;
            }
            int userId = generatedKeys.getInt(1);
            
            // Create profile for the user
            PreparedStatement insertProfileStmt = connection.prepareStatement(
                "INSERT INTO Profiles (user_id, display_name) VALUES (?, ?)"
            );
            insertProfileStmt.setInt(1, userId);
            insertProfileStmt.setString(2, username);
            insertProfileStmt.executeUpdate();
            
            // Create leaderboard entry for the user
            PreparedStatement insertLeaderboardStmt = connection.prepareStatement(
                "INSERT INTO Leaderboard (user_id) VALUES (?)"
            );
            insertLeaderboardStmt.setInt(1, userId);
            insertLeaderboardStmt.executeUpdate();
            
            connection.commit();
            connection.setAutoCommit(true);
            
            return true;
        } catch (SQLException e) {
            try {
                connection.rollback();
                connection.setAutoCommit(true);
            } catch (SQLException ex) {
                System.err.println("Rollback error: " + ex.getMessage());
            }
            System.err.println("Registration error: " + e.getMessage());
            return false;
        }
    }
    
    
     //Authenticates user based on username and password hash.
     
    public int authenticateUser(String username, String passwordHash) {
        try {
            PreparedStatement stmt = connection.prepareStatement(
                "SELECT id FROM Users WHERE username = ? AND password_hash = ?"
            );
            stmt.setString(1, username);
            stmt.setString(2, passwordHash);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                int userId = rs.getInt("id");
                
                // Update last login time
                PreparedStatement updateStmt = connection.prepareStatement(
                    "UPDATE Profiles SET last_login = CURRENT_TIMESTAMP WHERE user_id = ?"
                );
                updateStmt.setInt(1, userId);
                updateStmt.executeUpdate();
                
                return userId;
            }
            return -1;
        } catch (SQLException e) {
            System.err.println("Authentication error: " + e.getMessage());
            return -1;
        }
    }
    
    
    //Gets user profile data.
     
    public Map<String, Object> getUserProfile(int userId) {
        try {
            PreparedStatement stmt = connection.prepareStatement(
                "SELECT u.username, p.display_name, p.total_score, p.last_login, " +
                "l.current_level, l.highest_level, l.fastest_times " +
                "FROM Users u " +
                "JOIN Profiles p ON u.id = p.user_id " +
                "JOIN Leaderboard l ON u.id = l.user_id " +
                "WHERE u.id = ?"
            );
            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                Map<String, Object> profile = new HashMap<>();
                profile.put("username", rs.getString("username"));
                profile.put("displayName", rs.getString("display_name"));
                profile.put("totalScore", rs.getInt("total_score"));
                profile.put("lastLogin", rs.getString("last_login"));
                profile.put("currentLevel", rs.getInt("current_level"));
                profile.put("highestLevel", rs.getInt("highest_level"));
                profile.put("fastestTimes", rs.getString("fastest_times"));
                return profile;
            }
            return null;
        } catch (SQLException e) {
            System.err.println("Error getting user profile: " + e.getMessage());
            return null;
        }
    }
    
   
    //Updates a user's score and level information.
 
    public void updateUserProgress(int userId, int level, int score, int timeInSeconds) {
        try {
            connection.setAutoCommit(false);
            
            // Update profile score
            PreparedStatement updateProfileStmt = connection.prepareStatement(
                "UPDATE Profiles SET total_score = total_score + ? WHERE user_id = ?"
            );
            updateProfileStmt.setInt(1, score);
            updateProfileStmt.setInt(2, userId);
            updateProfileStmt.executeUpdate();
            
            // Get current leaderboard data
            PreparedStatement getLeaderboardStmt = connection.prepareStatement(
                "SELECT highest_level, fastest_times FROM Leaderboard WHERE user_id = ?"
            );
            getLeaderboardStmt.setInt(1, userId);
            ResultSet rs = getLeaderboardStmt.executeQuery();
            
            if (rs.next()) {
                int highestLevel = rs.getInt("highest_level");
                String fastestTimesJson = rs.getString("fastest_times");
                
                // Update highest level if needed
                if (level > highestLevel) {
                    highestLevel = level;
                }
                
                // Update fastest times
                JSONObject fastestTimes = new JSONObject(fastestTimesJson.isEmpty() ? "{}" : fastestTimesJson);
                String levelKey = String.valueOf(level);
                if (!fastestTimes.has(levelKey) || timeInSeconds < fastestTimes.getInt(levelKey)) {
                    fastestTimes.put(levelKey, timeInSeconds);
                }
                
                // Update leaderboard
                PreparedStatement updateLeaderboardStmt = connection.prepareStatement(
                    "UPDATE Leaderboard SET current_level = ?, highest_level = ?, fastest_times = ? WHERE user_id = ?"
                );
                updateLeaderboardStmt.setInt(1, level + 1); // Next level
                updateLeaderboardStmt.setInt(2, highestLevel);
                updateLeaderboardStmt.setString(3, fastestTimes.toString());
                updateLeaderboardStmt.setInt(4, userId);
                updateLeaderboardStmt.executeUpdate();
            }
            
            connection.commit();
            connection.setAutoCommit(true);
        } catch (SQLException e) {
            try {
                connection.rollback();
                connection.setAutoCommit(true);
            } catch (SQLException ex) {
                System.err.println("Rollback error: " + ex.getMessage());
            }
            System.err.println("Error updating user progress: " + e.getMessage());
        }
    }
    
    
    //Updates a player's score and level in the leaderboard in real-time.
    
    public boolean updateRealtimeScore(int userId, int score, int level) {
        try {
            connection.setAutoCommit(false);
            
            // Update profile with the current score
            PreparedStatement updateProfileStmt = connection.prepareStatement(
                "UPDATE Profiles SET total_score = ? WHERE user_id = ?"
            );
            updateProfileStmt.setInt(1, score);
            updateProfileStmt.setInt(2, userId);
            updateProfileStmt.executeUpdate();
            
            // Get current leaderboard data
            PreparedStatement getLeaderboardStmt = connection.prepareStatement(
                "SELECT highest_level FROM Leaderboard WHERE user_id = ?"
            );
            getLeaderboardStmt.setInt(1, userId);
            ResultSet rs = getLeaderboardStmt.executeQuery();
            
            if (rs.next()) {
                int highestLevel = rs.getInt("highest_level");
                
                // Update highest level if needed
                if (level > highestLevel) {
                    highestLevel = level;
                }
                
                // Update leaderboard with current level and highest level
                PreparedStatement updateLeaderboardStmt = connection.prepareStatement(
                    "UPDATE Leaderboard SET current_level = ?, highest_level = ? WHERE user_id = ?"
                );
                updateLeaderboardStmt.setInt(1, level);
                updateLeaderboardStmt.setInt(2, highestLevel);
                updateLeaderboardStmt.setInt(3, userId);
                updateLeaderboardStmt.executeUpdate();
            }
            
            connection.commit();
            connection.setAutoCommit(true);
            return true;
        } catch (SQLException e) {
            try {
                connection.rollback();
                connection.setAutoCommit(true);
            } catch (SQLException ex) {
                System.err.println("Error rolling back transaction: " + ex.getMessage());
            }
            System.err.println("Error updating real-time score: " + e.getMessage());
            return false;
        }
    }
    
   
    //Gets the player's current rank on the leaderboard.
    
    public int getPlayerRank(int userId) {
        try {
            PreparedStatement stmt = connection.prepareStatement(
                "SELECT COUNT(*) + 1 AS rank " +
                "FROM Profiles p " +
                "JOIN Leaderboard l ON p.user_id = l.user_id " +
                "WHERE p.total_score > (SELECT total_score FROM Profiles WHERE user_id = ?)"
            );
            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                return rs.getInt("rank");
            }
            return -1;
        } catch (SQLException e) {
            System.err.println("Error getting player rank: " + e.getMessage());
            return -1;
        }
    }
    
    
    //Gets the top players from the leaderboard.
    
    public List<Map<String, Object>> getLeaderboard(int limit) {
        List<Map<String, Object>> leaderboard = new ArrayList<>();
        
        try {
            PreparedStatement stmt = connection.prepareStatement(
                "SELECT u.username, p.display_name, p.total_score, l.highest_level " +
                "FROM Users u " +
                "JOIN Profiles p ON u.id = p.user_id " +
                "JOIN Leaderboard l ON u.id = l.user_id " +
                "ORDER BY p.total_score DESC, l.highest_level DESC " +
                "LIMIT ?"
            );
            stmt.setInt(1, limit);
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                Map<String, Object> entry = new HashMap<>();
                entry.put("username", rs.getString("username"));
                entry.put("displayName", rs.getString("display_name"));
                entry.put("totalScore", rs.getInt("total_score"));
                entry.put("highestLevel", rs.getInt("highest_level"));
                leaderboard.add(entry);
            }
        } catch (SQLException e) {
            System.err.println("Error getting leaderboard: " + e.getMessage());
        }
        
        return leaderboard;
    }
    
    
    //Logs a session activity in the database.
    
    public boolean logSessionActivity(int userId, String activityType, String sessionId) {
        try {
            PreparedStatement stmt = connection.prepareStatement(
                "INSERT INTO SessionLogs (user_id, session_id, activity_type) VALUES (?, ?, ?)"
            );
            stmt.setInt(1, userId);
            stmt.setString(2, sessionId);
            stmt.setString(3, activityType);
            
            int rowsAffected = stmt.executeUpdate();
            stmt.close();
            
            // Update last login time if this is a login activity
            if (activityType.equals("login")) {
                updateLastLoginTime(userId);
            }
            
            return rowsAffected > 0;
        } catch (SQLException e) {
            System.err.println("Error logging session activity: " + e.getMessage());
            return false;
        }
    }
    
    
    //Updates the last login time for a user.
    
    private void updateLastLoginTime(int userId) {
        try {
            PreparedStatement stmt = connection.prepareStatement(
                "UPDATE Profiles SET last_login = CURRENT_TIMESTAMP WHERE user_id = ?"
            );
            stmt.setInt(1, userId);
            stmt.executeUpdate();
            stmt.close();
        } catch (SQLException e) {
            System.err.println("Error updating last login time: " + e.getMessage());
        }
    }
    
    
    //Gets the session history for a user.
     
    public List<Map<String, Object>> getSessionHistory(int userId, int limit) {
        List<Map<String, Object>> sessions = new ArrayList<>();
        
        try {
            PreparedStatement stmt = connection.prepareStatement(
                "SELECT session_id, " +
                "MIN(CASE WHEN activity_type = 'login' THEN timestamp END) AS login_time, " +
                "MAX(CASE WHEN activity_type IN ('logout', 'timeout', 'shutdown') THEN timestamp END) AS logout_time " +
                "FROM SessionLogs " +
                "WHERE user_id = ? " +
                "GROUP BY session_id " +
                "ORDER BY login_time DESC " +
                "LIMIT ?"
            );
            stmt.setInt(1, userId);
            stmt.setInt(2, limit);
            
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                Map<String, Object> session = new HashMap<>();
                session.put("sessionId", rs.getString("session_id"));
                session.put("loginTime", rs.getString("login_time"));
                session.put("logoutTime", rs.getString("logout_time"));
                
                // Calculate duration if both login and logout times exist
                String loginTime = rs.getString("login_time");
                String logoutTime = rs.getString("logout_time");
                
                if (loginTime != null && logoutTime != null) {
                    // Simple string-based duration calculation for SQLite
                    session.put("duration", "Session ended");
                } else {
                    session.put("duration", "Session active");
                }
                
                sessions.add(session);
            }
            
            rs.close();
            stmt.close();
        } catch (SQLException e) {
            System.err.println("Error retrieving session history: " + e.getMessage());
        }
        
        return sessions;
    }
    
   
    //Gets the active session count for all users.
   
    public int getActiveSessionCount() {
        try {
            PreparedStatement stmt = connection.prepareStatement(
                "SELECT COUNT(DISTINCT session_id) AS active_count " +
                "FROM SessionLogs " +
                "WHERE session_id NOT IN (" +
                "  SELECT session_id FROM SessionLogs " +
                "  WHERE activity_type IN ('logout', 'timeout', 'shutdown')" +
                ")"
            );
            
            ResultSet rs = stmt.executeQuery();
            int count = rs.next() ? rs.getInt("active_count") : 0;
            
            rs.close();
            stmt.close();
            
            return count;
        } catch (SQLException e) {
            System.err.println("Error getting active session count: " + e.getMessage());
            return 0;
        }
    }
    
    
    //Closes the database connection.
     
    public void closeConnection() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
                System.out.println("Database connection closed.");
            }
        } catch (SQLException e) {
            System.err.println("Error closing database connection: " + e.getMessage());
        }
    }
} 