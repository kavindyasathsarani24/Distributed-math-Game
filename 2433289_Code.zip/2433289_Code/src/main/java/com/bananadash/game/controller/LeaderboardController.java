package com.bananadash.game.controller;

import com.bananadash.game.model.LeaderboardModel;
import com.bananadash.game.model.Player;
import com.bananadash.game.view.LeaderboardPanel;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

//Controller class for the leaderboard functionality.

public class LeaderboardController {
    private LeaderboardModel model;
    private LeaderboardPanel view;
    private Player currentPlayer;
    private static final long UPDATE_INTERVAL = 30000; // 30 seconds
    
   
    //Creates a new LeaderboardController.
    
    public LeaderboardController(LeaderboardModel model, LeaderboardPanel view) {
        this.model = model;
        this.view = view;
        
        // Set up event handlers
        setupEventHandlers();
    }
    
    //Sets up event handlers for the leaderboard view.
     
    private void setupEventHandlers() {
        // Set refresh button listener
        view.setRefreshButtonListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                refreshLeaderboard();
            }
        });
    }
    
   
    //Sets the current player.
    
    public void setCurrentPlayer(Player player) {
        this.currentPlayer = player;
    }
    
   
    //Refreshes the leaderboard data and updates the view.
    
    public void refreshLeaderboard() {
        // Fetch the latest leaderboard data
        List<Map<String, Object>> leaderboardData = model.fetchLeaderboardData();
        
        // Update the view with the new data
        view.updateLeaderboard(leaderboardData);
        
        // Highlight the current player if they're on the leaderboard
        if (currentPlayer != null) {
            view.highlightPlayer(currentPlayer.getDisplayName());
        }
        
        // Format the current time for the "last updated" label
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String currentTime = sdf.format(new Date());
        view.setLastUpdatedTime(currentTime);
    }
    
    
    //Updates the leaderboard if it hasn't been updated recently.
   
    public void updateIfNeeded() {
        long currentTime = System.currentTimeMillis();
        if (currentTime - model.getLastUpdateTime() > UPDATE_INTERVAL) {
            refreshLeaderboard();
        }
    }
    
    //Updates the player's score and refreshes the leaderboard.
     
    public void updatePlayerScore(int userId, int score, int level) {
        if (model.updatePlayerScore(userId, score, level)) {
            refreshLeaderboard();
        }
    }
    
    
    //Gets the player's current rank.
  
    public int getPlayerRank(int userId) {
        return model.getPlayerRank(userId);
    }
} 