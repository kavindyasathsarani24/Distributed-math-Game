package com.bananadash.game.utils;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.Base64;


//Utility class for decoding base64 encoded images.

public class Base64ImageDecoder {
    
    
    //Decodes a base64 string to a BufferedImage using multiple approaches.
     
    public static BufferedImage decodeToImage(String base64String) {
        if (base64String == null || base64String.isEmpty()) {
            System.err.println("Base64 string is null or empty");
            return null;
        }
        
        // Remove data:image prefix if present
        if (base64String.contains(",")) {
            base64String = base64String.split(",")[1];
        }
        
        // Try standard decoding
        try {
            byte[] imageBytes = Base64.getDecoder().decode(base64String);
            BufferedImage image = ImageIO.read(new ByteArrayInputStream(imageBytes));
            if (image != null) {
                return image;
            }
        } catch (IllegalArgumentException | IOException e) {
            System.err.println("Standard decoding failed: " + e.getMessage());
        }
        
        // Try with padding correction
        try {
            // Add padding if needed
            while (base64String.length() % 4 != 0) {
                base64String += "=";
            }
            
            byte[] imageBytes = Base64.getDecoder().decode(base64String);
            BufferedImage image = ImageIO.read(new ByteArrayInputStream(imageBytes));
            if (image != null) {
                return image;
            }
        } catch (IllegalArgumentException | IOException e) {
            System.err.println("Padding correction decoding failed: " + e.getMessage());
        }
        
        // Try with MIME decoder
        try {
            byte[] imageBytes = Base64.getMimeDecoder().decode(base64String);
            BufferedImage image = ImageIO.read(new ByteArrayInputStream(imageBytes));
            if (image != null) {
                return image;
            }
        } catch (IllegalArgumentException | IOException e) {
            System.err.println("MIME decoding failed: " + e.getMessage());
        }
        
        System.err.println("All decoding approaches failed");
        return null;
    }
} 