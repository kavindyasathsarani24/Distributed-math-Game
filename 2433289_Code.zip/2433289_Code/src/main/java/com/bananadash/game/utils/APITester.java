package com.bananadash.game.utils;

import org.json.JSONObject;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;


//Test class for verifying the Banana API functionality.

public class APITester {
    
    public static void main(String[] args) {
        System.out.println("Testing Banana API...");
        
        // Create API instance
        BananaAPI api = new BananaAPI();
        
        // Fetch puzzle
        System.out.println("Fetching puzzle...");
        JSONObject puzzleData = api.getPuzzle(true);
        
        if (puzzleData != null) {
            System.out.println("Puzzle fetched successfully!");
            System.out.println("Keys in puzzle data: " + puzzleData.keySet());
            
            // Try to load the image
            System.out.println("Loading puzzle image...");
            BufferedImage image = api.loadPuzzleImage(puzzleData);
            
            if (image != null) {
                System.out.println("Image loaded successfully!");
                System.out.println("Image dimensions: " + image.getWidth() + "x" + image.getHeight());
                
                // Save the image to a file for verification
                try {
                    File outputFile = new File("puzzle_image.png");
                    ImageIO.write(image, "png", outputFile);
                    System.out.println("Image saved to: " + outputFile.getAbsolutePath());
                } catch (IOException e) {
                    System.err.println("Error saving image: " + e.getMessage());
                }
                
                // Check the solution
                if (puzzleData.has("solution")) {
                    int solution = puzzleData.getInt("solution");
                    System.out.println("Correct answer: " + solution);
                } else {
                    System.err.println("No solution found in puzzle data");
                }
            } else {
                System.err.println("Failed to load puzzle image");
            }
        } else {
            System.err.println("Failed to fetch puzzle data");
        }
    }
} 