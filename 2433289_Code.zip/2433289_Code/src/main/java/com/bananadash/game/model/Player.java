package com.bananadash.game.model;


//Represents a player in the Banana Dash game.
 
public class Player {
    private int userId;
    private String username;
    private String displayName;
    private int currentLevel;
    private int totalScore;
    private int currentLevelScore;
    private int consecutiveCorrectAnswers;
    private int currentRank;
    private LeaderboardModel leaderboardModel;
    private DatabaseManager databaseManager;
    
    
    //Creates a new Player instance.
    
    public Player(int userId, String username, String displayName, int currentLevel, int totalScore) {
        this.userId = userId;
        this.username = username;
        this.displayName = displayName;
        this.currentLevel = currentLevel;
        this.totalScore = totalScore;
        this.currentLevelScore = 0;
        this.consecutiveCorrectAnswers = 0;
        this.currentRank = -1;
    }
    
    
    //Sets the leaderboard model for real-time leaderboard updates.
     
    public void setLeaderboardModel(LeaderboardModel leaderboardModel) {
        this.leaderboardModel = leaderboardModel;
        // Initialize rank
        updateRank();
    }
    
   
    //Sets the database manager for real-time leaderboard updates.
    
    public void setDatabaseManager(DatabaseManager databaseManager) {
        this.databaseManager = databaseManager;
        // Initialize rank
        updateRankLegacy();
    }
    
    
    //Calculates the score for a correct answer.
   
    public int calculateScore(int timeRemaining) {
        // Base points for correct answer
        int basePoints = 100;
        
        // For penalties (like hints), just use the timeRemaining as the score adjustment
        int score;
        if (timeRemaining < 0) {
            score = timeRemaining;  // This will be negative for penalties
        } else {
            // Time bonus: remaining seconds × 10
            int timeBonus = timeRemaining * 10;
            
            // Streak bonus: consecutive correct answers × 20
            int streakBonus = consecutiveCorrectAnswers * 20;
            
            // Level completion bonus: level × 50
            int levelBonus = currentLevel * 50;
            
            // Calculate total score for this answer
            score = basePoints + timeBonus + streakBonus + levelBonus;
        }
        
        // Update player state
        currentLevelScore += score;
        totalScore += score;
        
        if (timeRemaining >= 0) {  // Only increment streak for correct answers, not penalties
            consecutiveCorrectAnswers++;
        }
        
        // Update leaderboard in real-time
        updateLeaderboardRealtime();
        
        return score;
    }
    
    
    //Updates the leaderboard in real-time.
     
    private void updateLeaderboardRealtime() {
        if (leaderboardModel != null) {
            leaderboardModel.updatePlayerScore(userId, totalScore, currentLevel);
            updateRank();
        } else if (databaseManager != null) {
            databaseManager.updateRealtimeScore(userId, totalScore, currentLevel);
            updateRankLegacy();
        }
    }
    
    
    //Updates the player's current rank.
     
    private void updateRank() {
        if (leaderboardModel != null) {
            currentRank = leaderboardModel.getPlayerRank(userId);
        } else if (databaseManager != null) {
            updateRankLegacy();
        }
    }
    
    //Updates the player's current rank using the legacy method.
     
    private void updateRankLegacy() {
        if (databaseManager != null) {
            currentRank = databaseManager.getPlayerRank(userId);
        }
    }
    
    
    //Advances the player to the next level.
     
    public void advanceLevel() {
        currentLevel++;
        currentLevelScore = 0;
        
        // Update leaderboard in real-time if leaderboard model is available
        updateLeaderboardRealtime();
    }
    
    
    //Resets the consecutive correct answers counter.
    
    public void resetStreak() {
        consecutiveCorrectAnswers = 0;
    }
    
    
    //Gets the time limit for the current level in seconds.
     
    public int getCurrentLevelTimeLimit() {
        // Level 1: 120 seconds
        // Each subsequent level: half of the previous level's time
        return (int) (120 / Math.pow(2, currentLevel - 1));
    }
    
    // Getters and setters
    
    public int getUserId() {
        return userId;
    }
    
    public String getUsername() {
        return username;
    }
    
    public String getDisplayName() {
        return displayName;
    }
    
    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }
    
    public int getCurrentLevel() {
        return currentLevel;
    }
    
    public void setCurrentLevel(int currentLevel) {
        this.currentLevel = currentLevel;
        
        // Update leaderboard in real-time if leaderboard model is available
        updateLeaderboardRealtime();
    }
    
    public int getTotalScore() {
        return totalScore;
    }
    
    
    //Sets the player's total score.
    
    public void setTotalScore(int totalScore) {
        this.totalScore = totalScore;
    }
    
    public int getCurrentLevelScore() {
        return currentLevelScore;
    }
    
    public int getConsecutiveCorrectAnswers() {
        return consecutiveCorrectAnswers;
    }
    
    public int getCurrentRank() {
        return currentRank;
    }
} 