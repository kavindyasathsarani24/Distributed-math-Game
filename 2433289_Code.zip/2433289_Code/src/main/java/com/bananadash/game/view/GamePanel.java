package com.bananadash.game.view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;

//The game screen for the Banana Dash game.
 
public class GamePanel extends JPanel {
    private GameFrame parentFrame;
    private JLabel levelLabel;
    private JLabel timerLabel;
    private JLabel scoreLabel;
    private JLabel puzzleLabel;
    private JTextField answerField;
    private JButton submitButton;
    private JButton hintButton;
    private JProgressBar timerProgressBar;
    private Timer uiTimer;
    
    //Creates a new GamePanel.
    
    public GamePanel(GameFrame parentFrame) {
        this.parentFrame = parentFrame;
        
        // Set up the panel
        setLayout(new BorderLayout());
        setBackground(new Color(102, 51, 0)); // Blue background
        
        // Create top panel for level and timer
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setOpaque(false);
        topPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        // Create level and score panel
        JPanel levelScorePanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 0));
        levelScorePanel.setOpaque(false);
        
        // Create level label
        levelLabel = new JLabel("Level 1");
        levelLabel.setFont(new Font("Arial", Font.BOLD, 24));
        levelLabel.setForeground(Color.WHITE);
        levelScorePanel.add(levelLabel);
        
        // Create score label
        scoreLabel = new JLabel("Score: 0");
        scoreLabel.setFont(new Font("Arial", Font.BOLD, 24));
        scoreLabel.setForeground(Color.WHITE);
        levelScorePanel.add(scoreLabel);
        
        topPanel.add(levelScorePanel, BorderLayout.WEST);
        
        // Create timer panel
        JPanel timerPanel = new JPanel(new BorderLayout());
        timerPanel.setOpaque(false);
        
        // Create timer label
        timerLabel = new JLabel("Time: 60s");
        timerLabel.setFont(new Font("Arial", Font.BOLD, 24));
        timerLabel.setForeground(Color.WHITE);
        timerPanel.add(timerLabel, BorderLayout.NORTH);
        
        // Create timer progress bar
        timerProgressBar = new JProgressBar(0, 100);
        timerProgressBar.setValue(100);
        timerProgressBar.setForeground(new Color(76, 175, 80)); // Green
        timerProgressBar.setPreferredSize(new Dimension(200, 20));
        timerPanel.add(timerProgressBar, BorderLayout.SOUTH);
        
        topPanel.add(timerPanel, BorderLayout.EAST);
        
        // Create center panel for puzzle
        JPanel centerPanel = new JPanel(new BorderLayout());
        centerPanel.setOpaque(false);
        centerPanel.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        
        // Create puzzle panel with a border
        JPanel puzzlePanel = new JPanel(new BorderLayout());
        puzzlePanel.setOpaque(false);
        puzzlePanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createEmptyBorder(10, 10, 10, 10),
            BorderFactory.createLineBorder(Color.WHITE, 2)
        ));
        
        // Create puzzle label
        puzzleLabel = new JLabel("Loading puzzle...", JLabel.CENTER);
        puzzleLabel.setFont(new Font("Arial", Font.PLAIN, 18));
        puzzleLabel.setForeground(Color.WHITE);
        puzzleLabel.setPreferredSize(new Dimension(650, 500)); // Increased dimensions
        puzzleLabel.setHorizontalAlignment(JLabel.CENTER);
        puzzleLabel.setVerticalAlignment(JLabel.CENTER);
        puzzlePanel.add(puzzleLabel, BorderLayout.CENTER);
        
        centerPanel.add(puzzlePanel, BorderLayout.CENTER);
        
        // Create bottom panel for answer input and buttons
        JPanel bottomPanel = new JPanel(new BorderLayout());
        bottomPanel.setOpaque(false);
        bottomPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        // Create answer panel
        JPanel answerPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        answerPanel.setOpaque(false);
        
        // Create answer label
        JLabel answerLabel = new JLabel("Your Answer:");
        answerLabel.setFont(new Font("Arial", Font.BOLD, 18));
        answerLabel.setForeground(Color.WHITE);
        answerPanel.add(answerLabel);
        
        // Create answer field
        answerField = new JTextField(5);
        answerField.setFont(new Font("Arial", Font.PLAIN, 18));
        answerPanel.add(answerField);
        
        bottomPanel.add(answerPanel, BorderLayout.CENTER);
        
        // Create buttons panel
        JPanel buttonsPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        buttonsPanel.setOpaque(false);
        
        // Create submit button
        submitButton = new JButton("Submit");
        submitButton.setFont(new Font("Arial", Font.BOLD, 16));
        submitButton.setBackground(new Color(255, 153, 0)); // Orange button
        submitButton.setForeground(new Color(102,51,0));
        submitButton.setFocusPainted(false);
        submitButton.setBorder(BorderFactory.createRaisedBevelBorder());
        submitButton.setPreferredSize(new Dimension(120, 40));
        
        // Create hint button
        hintButton = new JButton("Hint");
        hintButton.setFont(new Font("Arial", Font.BOLD, 16));
        hintButton.setBackground(new Color(255, 153, 0)); // Amber button
        hintButton.setForeground(new Color(102,51,0));
        hintButton.setFocusPainted(false);
        hintButton.setBorder(BorderFactory.createRaisedBevelBorder());
        hintButton.setPreferredSize(new Dimension(120, 40));
        
        // Create back button
        JButton backButton = new JButton("Back to Home");
        backButton.setFont(new Font("Arial", Font.BOLD, 16));
        backButton.setBackground(new Color(255, 153, 0)); // Gray button
        backButton.setForeground(new Color(102,51,0));
        backButton.setFocusPainted(false);
        backButton.setBorder(BorderFactory.createRaisedBevelBorder());
        backButton.setPreferredSize(new Dimension(150, 40));
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Stop the timer and return to home
                uiTimer.stop();
                parentFrame.showPanel("home");
            }
        });
        
        buttonsPanel.add(submitButton);
        buttonsPanel.add(Box.createRigidArea(new Dimension(20, 0)));
        buttonsPanel.add(hintButton);
        buttonsPanel.add(Box.createRigidArea(new Dimension(20, 0)));
        buttonsPanel.add(backButton);
        
        bottomPanel.add(buttonsPanel, BorderLayout.SOUTH);
        
        // Add components to the main panel
        add(topPanel, BorderLayout.NORTH);
        add(centerPanel, BorderLayout.CENTER);
        add(bottomPanel, BorderLayout.SOUTH);
        
        // Create UI timer for updating the progress bar
        uiTimer = new Timer(100, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // This will be updated by the controller
            }
        });
    }
    
    //Sets the level display.
    
    public void setLevel(int level) {
        levelLabel.setText("Level " + level);
    }
    
    //Sets the timer display.
    
    public void setTimer(int seconds, int maxSeconds) {
        timerLabel.setText("Time: " + seconds + "s");
        
        // Update progress bar
        int percentage = (int) ((seconds / (double) maxSeconds) * 100);
        timerProgressBar.setValue(percentage);
        
        // Change color based on time remaining
        if (percentage > 66) {
            timerProgressBar.setForeground(new Color(76, 175, 80)); // Green
        } else if (percentage > 33) {
            timerProgressBar.setForeground(new Color(255, 235, 59)); // Yellow
        } else {
            timerProgressBar.setForeground(new Color(244, 67, 54)); // Red
        }
    }
    
    //Sets the puzzle image to display.
    
    public void setPuzzleImage(BufferedImage image) {
        if (image != null) {
            // Scale the image to fit the puzzle label while maintaining aspect ratio
            int maxWidth = 600;  // Increased from 400
            int maxHeight = 450; // Increased from 300
            
            double widthRatio = (double) maxWidth / image.getWidth();
            double heightRatio = (double) maxHeight / image.getHeight();
            double ratio = Math.min(widthRatio, heightRatio);
            
            int scaledWidth = (int) (image.getWidth() * ratio);
            int scaledHeight = (int) (image.getHeight() * ratio);
            
            // Create a scaled version of the image
            Image scaledImage = image.getScaledInstance(scaledWidth, scaledHeight, Image.SCALE_SMOOTH);
            ImageIcon icon = new ImageIcon(scaledImage);
            
            // Set the icon on the puzzle label
            puzzleLabel.setIcon(icon);
            puzzleLabel.setText("");
            System.out.println("Puzzle image set successfully with dimensions: " + scaledWidth + "x" + scaledHeight);
        } else {
            // Display an error message if the image is null
            puzzleLabel.setIcon(null);
            puzzleLabel.setText("Error loading puzzle image");
            System.err.println("Failed to set puzzle image: image is null");
        }
    }
    
    //Gets the answer entered by the user.
    
    public int getAnswer() throws NumberFormatException {
        String answerText = answerField.getText().trim();
        if (answerText.isEmpty()) {
            throw new NumberFormatException("Empty input");
        }
        return Integer.parseInt(answerText);
    }
    
   
    //Clears the answer field.
     
    public void clearAnswer() {
        answerField.setText("");
        answerField.requestFocus();
    }
    
    //Sets the submit button action listener.
   
    public void setSubmitButtonListener(ActionListener listener) {
        // Remove existing listeners
        for (ActionListener al : submitButton.getActionListeners()) {
            submitButton.removeActionListener(al);
        }
        
        // Add new listener
        submitButton.addActionListener(listener);
    }
    
    
    //Sets the hint button action listener.
     
    public void setHintButtonListener(ActionListener listener) {
        // Remove existing listeners
        for (ActionListener al : hintButton.getActionListeners()) {
            hintButton.removeActionListener(al);
        }
        
        // Add new listener
        hintButton.addActionListener(listener);
    }
    
    //Sets the UI timer action listener.
    
    public void setUiTimerListener(ActionListener listener) {
        // Remove existing listeners
        for (ActionListener al : uiTimer.getActionListeners()) {
            uiTimer.removeActionListener(al);
        }
        
        // Add new listener
        uiTimer.addActionListener(listener);
    }
    
    
    //Starts the UI timer.
    
    public void startGame() {
        uiTimer.start();
        answerField.setEnabled(true);
        submitButton.setEnabled(true);
        hintButton.setEnabled(true);
    }
    
    //Stops the UI timer.
     
    public void stopGame() {
        uiTimer.stop();
        answerField.setEnabled(false);
        submitButton.setEnabled(false);
        hintButton.setEnabled(false);
    }
    
    //Shows a hint message.
    
    public void showHint(String hint) {
        JOptionPane.showMessageDialog(this, hint, "Hint", JOptionPane.INFORMATION_MESSAGE);
    }
    

    //Updates the score display.
    
    public void updateScore(int score) {
        scoreLabel.setText("Score: " + score);
    }
    
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        
        // Draw a gradient background
        Graphics2D g2d = (Graphics2D) g;
        GradientPaint gradient = new GradientPaint(
            0, 0, new Color(102, 51, 0),
            0, getHeight(), new Color(204, 102, 0)
        );
        g2d.setPaint(gradient);
        g2d.fillRect(0, 0, getWidth(), getHeight());
    }
} 