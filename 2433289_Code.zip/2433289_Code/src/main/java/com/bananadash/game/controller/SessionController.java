package com.bananadash.game.controller;

import com.bananadash.game.model.DatabaseManager;
import com.bananadash.game.model.UserSession;

import java.util.HashMap;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;


//Controller for managing user sessions in the Banana Dash game.
 
public class SessionController {
    private static final int SESSION_TIMEOUT_MINUTES = 30;
    private static final int CLEANUP_INTERVAL_MINUTES = 5;
    
    private Map<String, UserSession> activeSessions;
    private DatabaseManager databaseManager;
    private Timer sessionCleanupTimer;
    
    
    //Creates a new SessionController.
     
    public SessionController(DatabaseManager databaseManager) {
        this.databaseManager = databaseManager;
        this.activeSessions = new HashMap<>();
        
        // Start session cleanup timer
        startSessionCleanupTimer();
    }
    
    
    //Creates a new user session.
   
    public UserSession createSession(int userId, String username) {
        // End any existing sessions for this user
        endUserSessions(userId);
        
        // Create new session
        UserSession session = new UserSession(userId, username);
        activeSessions.put(session.getSessionId(), session);
        
        // Log session start in database
        databaseManager.logSessionActivity(userId, "login", session.getSessionId());
        
        return session;
    }
    
    
    //Gets a user session by session ID.
   
    public UserSession getSession(String sessionId) {
        return activeSessions.get(sessionId);
    }
    
    
    //Validates a session and updates its activity timestamp.
    
    public boolean validateSession(String sessionId) {
        UserSession session = activeSessions.get(sessionId);
        
        if (session == null || !session.isActive() || session.hasTimedOut(SESSION_TIMEOUT_MINUTES)) {
            // Session is invalid or has timed out
            if (session != null) {
                endSession(sessionId);
            }
            return false;
        }
        
        // Update last activity time
        session.updateActivity();
        return true;
    }
    
  
    //Ends a user session.
    
    public void endSession(String sessionId) {
        UserSession session = activeSessions.get(sessionId);
        
        if (session != null) {
            session.endSession();
            
            // Log session end in database
            databaseManager.logSessionActivity(session.getUserId(), "logout", sessionId);
            
            // Remove from active sessions
            activeSessions.remove(sessionId);
        }
    }
    
    
    //Ends all sessions for a specific user.
   
    private void endUserSessions(int userId) {
        // Find and end all sessions for this user
        activeSessions.entrySet().removeIf(entry -> {
            UserSession session = entry.getValue();
            if (session.getUserId() == userId) {
                session.endSession();
                databaseManager.logSessionActivity(userId, "logout", session.getSessionId());
                return true;
            }
            return false;
        });
    }
    
   
    //Starts the session cleanup timer.
     
    private void startSessionCleanupTimer() {
        sessionCleanupTimer = new Timer(true);
        sessionCleanupTimer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                cleanupExpiredSessions();
            }
        }, CLEANUP_INTERVAL_MINUTES * 60 * 1000, CLEANUP_INTERVAL_MINUTES * 60 * 1000);
    }
    
   
    //Cleans up expired sessions.
    
    private void cleanupExpiredSessions() {
        // Find and remove expired sessions
        activeSessions.entrySet().removeIf(entry -> {
            UserSession session = entry.getValue();
            if (!session.isActive() || session.hasTimedOut(SESSION_TIMEOUT_MINUTES)) {
                // Log session timeout in database
                if (session.isActive()) {
                    databaseManager.logSessionActivity(session.getUserId(), "timeout", session.getSessionId());
                    session.endSession();
                }
                return true;
            }
            return false;
        });
    }
    
    
    //Stops the session cleanup timer.
    
    public void shutdown() {
        if (sessionCleanupTimer != null) {
            sessionCleanupTimer.cancel();
        }
        
        // End all active sessions
        for (UserSession session : activeSessions.values()) {
            session.endSession();
            databaseManager.logSessionActivity(session.getUserId(), "shutdown", session.getSessionId());
        }
        
        activeSessions.clear();
    }
} 