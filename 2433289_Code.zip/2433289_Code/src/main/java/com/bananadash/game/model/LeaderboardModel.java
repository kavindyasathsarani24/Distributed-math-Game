package com.bananadash.game.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


//Model class for the leaderboard functionality.

public class LeaderboardModel {
    private DatabaseManager databaseManager;
    private List<Map<String, Object>> leaderboardData;
    private long lastUpdateTime;
    private static final int DEFAULT_LIMIT = 10;
    
    
    //Creates a new LeaderboardModel.
    
    public LeaderboardModel(DatabaseManager databaseManager) {
        this.databaseManager = databaseManager;
        this.leaderboardData = new ArrayList<>();
        this.lastUpdateTime = 0;
    }
    
    
    //Fetches the latest leaderboard data from the database.
     
    public List<Map<String, Object>> fetchLeaderboardData(int limit) {
        if (databaseManager != null) {
            leaderboardData = databaseManager.getLeaderboard(limit);
            lastUpdateTime = System.currentTimeMillis();
        }
        return leaderboardData;
    }
    
    
    //Fetches the latest leaderboard data with the default limit.
     
    public List<Map<String, Object>> fetchLeaderboardData() {
        return fetchLeaderboardData(DEFAULT_LIMIT);
    }
    
    
    //Gets the current leaderboard data without fetching from the database.
     
    public List<Map<String, Object>> getLeaderboardData() {
        return leaderboardData;
    }
    
   
    //Gets the rank of a player in the leaderboard.
    
    public int getPlayerRank(int userId) {
        if (databaseManager != null) {
            return databaseManager.getPlayerRank(userId);
        }
        return -1;
    }
    
    
    //Updates a player's score and level in the leaderboard.
    
    public boolean updatePlayerScore(int userId, int score, int level) {
        if (databaseManager != null) {
            boolean result = databaseManager.updateRealtimeScore(userId, score, level);
            // If the update was successful, refresh the leaderboard data
            if (result) {
                fetchLeaderboardData();
            }
            return result;
        }
        return false;
    }
    
    //Get the time of the last leaderboard update.
     
    public long getLastUpdateTime() {
        return lastUpdateTime;
    }
    
    
    //Checks if a player is in the current leaderboard data.
    
    public boolean isPlayerInLeaderboard(String displayName) {
        if (displayName == null || displayName.isEmpty() || leaderboardData == null) {
            return false;
        }
        
        for (Map<String, Object> entry : leaderboardData) {
            String name = (String) entry.get("displayName");
            if (displayName.equals(name)) {
                return true;
            }
        }
        
        return false;
    }
    
    
    //Get player's position in the current leaderboard data.
   
    public int getPlayerPosition(String displayName) {
        if (displayName == null || displayName.isEmpty() || leaderboardData == null) {
            return -1;
        }
        
        for (int i = 0; i < leaderboardData.size(); i++) {
            String name = (String) leaderboardData.get(i).get("displayName");
            if (displayName.equals(name)) {
                return i;
            }
        }
        
        return -1;
    }
} 