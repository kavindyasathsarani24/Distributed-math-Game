package com.bananadash.game.view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


//Startup screen for the Banana Dash game.
 
public class StartupPanel extends JPanel {
    private GameFrame parentFrame;
    
    
    //Create new StartupPanel.
     
    public StartupPanel(GameFrame parentFrame) {
        this.parentFrame = parentFrame;
        
        // Set up the panel
        setLayout(new BorderLayout());
        setBackground(new Color(102, 51, 0)); // Brown background
        
        // Create title panel
        JPanel titlePanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        titlePanel.setOpaque(false);
        
        // Create title label
        JLabel titleLabel = new JLabel("Welcome to Banana Dash");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 48));
        titleLabel.setForeground(Color.WHITE);
        titlePanel.add(titleLabel);
        
        // Create buttons panel
        JPanel buttonsPanel = new JPanel();
        buttonsPanel.setLayout(new BoxLayout(buttonsPanel, BoxLayout.Y_AXIS));
        buttonsPanel.setOpaque(false);
        
        // Create login button in startup panel
        JButton loginButton = createButton("Login");
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                parentFrame.getGameController().navigateToLogin();
            }
        });
        
        // Create register button in startup panel
        JButton registerButton = createButton("Register");
        registerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                parentFrame.getGameController().navigateToRegister();
            }
        });
        
        // Create exit button in startup panel
        JButton exitButton = createButton("Exit");
        exitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
        
        // Add buttons to the panel 
        buttonsPanel.add(Box.createVerticalGlue());
        buttonsPanel.add(loginButton);
        buttonsPanel.add(Box.createRigidArea(new Dimension(0, 20)));
        buttonsPanel.add(registerButton);
        buttonsPanel.add(Box.createRigidArea(new Dimension(0, 20)));
        buttonsPanel.add(exitButton);
        buttonsPanel.add(Box.createVerticalGlue());
        
        // Add components to the main panel
        add(titlePanel, BorderLayout.NORTH);
        add(buttonsPanel, BorderLayout.CENTER);
    }
    
    
    //Create styled buttons
     
     
    private JButton createButton(String text) {
        JButton button = new JButton(text);
        button.setFont(new Font("Arial", Font.BOLD, 16));
        button.setBackground(new Color(255, 153, 0)); // Orange button
        button.setForeground(new Color(102,51,0));
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createRaisedBevelBorder());
        button.setPreferredSize(new Dimension(200, 50));
        button.setMaximumSize(new Dimension(200, 50));
        button.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        return button;
    }
    
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        
        // Draw a gradient background
        Graphics2D g2d = (Graphics2D) g;
        GradientPaint gradient = new GradientPaint(
            0, 0, new Color(102, 51, 0),
            0, getHeight(), new Color(204, 102, 0)
        );
        g2d.setPaint(gradient);
        g2d.fillRect(0, 0, getWidth(), getHeight());
        
        // Draw decorative bananas
        drawBananas(g2d);
    }
    
    
    //Draws decorative bananas on the background.
     
    
    private void drawBananas(Graphics2D g2d) {
        // Set banana color
        g2d.setColor(new Color(255, 235, 59, 100)); // Semi transparent yellow
        
        // Draw stylized bananas
        for (int i = 0; i < 10; i++) {
            int x = (int) (Math.random() * getWidth());
            int y = (int) (Math.random() * getHeight());
            int size = 20 + (int) (Math.random() * 30);
            
            // Draw a curved banana shape
            g2d.setStroke(new BasicStroke(size / 5f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            g2d.drawArc(x, y, size, size * 2, 30, 120);
        }
    }
} 