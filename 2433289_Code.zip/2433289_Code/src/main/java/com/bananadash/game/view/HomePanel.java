package com.bananadash.game.view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.awt.image.BufferedImage;
import com.bananadash.game.utils.FontManager;

//The home screen for the Banana Dash game.
 
public class HomePanel extends JPanel {
    private GameFrame parentFrame;
    private JLabel welcomeLabel;
    private JButton startGameButton;
    
    //Creates a new HomePanel.
   
    public HomePanel(GameFrame parentFrame) {
        this.parentFrame = parentFrame;
        
        // Set up the panel
        setLayout(new BorderLayout());
        setBackground(new Color(102, 51, 0)); // Brown background
        
        // Create top panel to hold welcome and logo
        JPanel topPanel = new JPanel();
        topPanel.setLayout(new BoxLayout(topPanel, BoxLayout.Y_AXIS));
        topPanel.setOpaque(false);
        
        // Create welcome panel
        JPanel welcomePanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        welcomePanel.setOpaque(false);
        
        // Create welcome label
        welcomeLabel = new JLabel("Welcome to Banana Dash!");
        welcomeLabel.setFont(FontManager.getHeadingFont());
        welcomeLabel.setForeground(Color.WHITE);
        welcomePanel.add(welcomeLabel);
        
        // Create text logo panel (for BANANA DASH text)
        JPanel textLogoPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        textLogoPanel.setOpaque(false);
        
        // Create logo label with text "BANANA" in yellow
        JLabel bananaLabel = new JLabel("BANANA");
        bananaLabel.setFont(FontManager.getGameTitleFont());
        bananaLabel.setForeground(new Color(255, 225, 53)); // Keep the yellow color
        
        // Create logo label with text "DASH" in yellow
        JLabel dashLabel = new JLabel("DASH");
        dashLabel.setFont(FontManager.getGameTitleFont());
        dashLabel.setForeground(new Color(255, 225, 53)); // Keep the yellow color
        
        // Add text components to the logo panel
        textLogoPanel.add(bananaLabel);
        textLogoPanel.add(Box.createRigidArea(new Dimension(20, 0))); // Space between words
        textLogoPanel.add(dashLabel);
        
        // Create a panel for the banana logo
        JPanel logoPanel = new JPanel();
        logoPanel.setOpaque(false);
        logoPanel.setPreferredSize(new Dimension(300, 150));
        logoPanel.setLayout(new BorderLayout());
        
        // Create label for the banana bunch logo image
        JLabel logoImageLabel = new JLabel();
        logoImageLabel.setHorizontalAlignment(JLabel.CENTER);
        
        // Current working directory
        String workingDir = System.getProperty("user.dir");
        System.out.println("Working directory: " + workingDir);
        
        // Try all possible paths to find the logo image
        boolean imageLoaded = false;
        
        try {
            // First try: absolute path
            File logoFile1 = new File(workingDir + "/src/main/resources/images/LOGO.png");
            System.out.println("Trying path 1: " + logoFile1.getAbsolutePath() + " (exists: " + logoFile1.exists() + ")");
            
            // Second try: relative path
            File logoFile2 = new File("src/main/resources/images/LOGO.png");
            System.out.println("Trying path 2: " + logoFile2.getAbsolutePath() + " (exists: " + logoFile2.exists() + ")");
            
            // Third try: backslash path (Windows style)
            File logoFile3 = new File(workingDir + "\\src\\main\\resources\\images\\LOGO.png");
            System.out.println("Trying path 3: " + logoFile3.getAbsolutePath() + " (exists: " + logoFile3.exists() + ")");
            
            // Try all paths
            if (logoFile1.exists()) {
                Image img = ImageIO.read(logoFile1);
                // Preserve aspect ratio when scaling
                int originalWidth = img.getWidth(null);
                int originalHeight = img.getHeight(null);
                double ratio = (double) originalWidth / originalHeight;
                int targetHeight = 150;
                int targetWidth = (int) (targetHeight * ratio);
                Image scaledImg = img.getScaledInstance(targetWidth, targetHeight, Image.SCALE_SMOOTH);
                logoImageLabel.setIcon(new ImageIcon(scaledImg));
                System.out.println("Loaded image from path 1");
                imageLoaded = true;
            } else if (logoFile2.exists()) {
                Image img = ImageIO.read(logoFile2);
                // Preserve aspect ratio when scaling
                int originalWidth = img.getWidth(null);
                int originalHeight = img.getHeight(null);
                double ratio = (double) originalWidth / originalHeight;
                int targetHeight = 150;
                int targetWidth = (int) (targetHeight * ratio);
                Image scaledImg = img.getScaledInstance(targetWidth, targetHeight, Image.SCALE_SMOOTH);
                logoImageLabel.setIcon(new ImageIcon(scaledImg));
                System.out.println("Loaded image from path 2");
                imageLoaded = true;
            } else if (logoFile3.exists()) {
                Image img = ImageIO.read(logoFile3);
                // Preserve aspect ratio when scaling
                int originalWidth = img.getWidth(null);
                int originalHeight = img.getHeight(null);
                double ratio = (double) originalWidth / originalHeight;
                int targetHeight = 150;
                int targetWidth = (int) (targetHeight * ratio);
                Image scaledImg = img.getScaledInstance(targetWidth, targetHeight, Image.SCALE_SMOOTH);
                logoImageLabel.setIcon(new ImageIcon(scaledImg));
                System.out.println("Loaded image from path 3");
                imageLoaded = true;
            } else {
                // Try from resources
                InputStream is = getClass().getResourceAsStream("/images/LOGO.png");
                if (is != null) {
                    Image img = ImageIO.read(is);
                    // Preserve aspect ratio when scaling
                    int originalWidth = img.getWidth(null);
                    int originalHeight = img.getHeight(null);
                    double ratio = (double) originalWidth / originalHeight;
                    int targetHeight = 150;
                    int targetWidth = (int) (targetHeight * ratio);
                    Image scaledImg = img.getScaledInstance(targetWidth, targetHeight, Image.SCALE_SMOOTH);
                    logoImageLabel.setIcon(new ImageIcon(scaledImg));
                    System.out.println("Loaded image from resources");
                    imageLoaded = true;
                }
            }
        } catch (Exception e) {
            System.err.println("Error loading image: " + e.getMessage());
            e.printStackTrace();
        }
        
        // If all loading attempts failed, create fallback icon
        if (!imageLoaded) {
            System.out.println("All image loading attempts failed. Using fallback icon.");
            logoImageLabel.setIcon(createBananaIcon());
        }
        
        logoPanel.add(logoImageLabel, BorderLayout.CENTER);
        
        // Add welcome and logos to top panel
        topPanel.add(welcomePanel);
        topPanel.add(Box.createRigidArea(new Dimension(0, 10))); // Space between welcome and text logo
        topPanel.add(textLogoPanel);
        topPanel.add(Box.createRigidArea(new Dimension(0, 20))); // Space between text logo and image logo
        topPanel.add(logoPanel);
        topPanel.add(Box.createRigidArea(new Dimension(0, 30))); // Space between logos and buttons
        
        // Main content panel for central alignment
        JPanel contentPanel = new JPanel(new BorderLayout());
        contentPanel.setOpaque(false);
        contentPanel.add(topPanel, BorderLayout.NORTH);
        
        // Create buttons panel with a grid layout instead of box layout
        JPanel buttonsPanel = new JPanel(new GridLayout(2, 2, 15, 15)); // 2 rows, 2 columns, 15px gaps
        buttonsPanel.setOpaque(false);
        buttonsPanel.setBorder(BorderFactory.createEmptyBorder(0, 20, 0, 20)); // Add some padding
        
        // Create start game button
        startGameButton = createButton("Start Game");
        startGameButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                parentFrame.showPanel("game");
            }
        });
        
        // Create profile button
        JButton profileButton = createButton("Profile");
        profileButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                parentFrame.showPanel("profile");
            }
        });
        
        // Create leaderboard button
        JButton leaderboardButton = createButton("Leaderboard");
        leaderboardButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                parentFrame.showPanel("leaderboard");
            }
        });
        
        // Create logout button
        JButton logoutButton = createButton("Logout");
        logoutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Perform logout actions
                parentFrame.showPanel("startup");
            }
        });
        
        // Add buttons directly to the grid layout panel
        buttonsPanel.add(startGameButton);
        buttonsPanel.add(profileButton);
        buttonsPanel.add(leaderboardButton);
        buttonsPanel.add(logoutButton);
        
        // Center the buttons panel
        JPanel centerButtonsPanel = new JPanel(new GridBagLayout());
        centerButtonsPanel.setOpaque(false);
        centerButtonsPanel.add(buttonsPanel);
        contentPanel.add(centerButtonsPanel, BorderLayout.CENTER);
        
        // Add content to the main panel
        add(contentPanel, BorderLayout.CENTER);
    }
    
    //Creates a custom banana icon
     
    private ImageIcon createBananaIcon() {
        // Create an image for the banana icon
        BufferedImage bufferedImage = new BufferedImage(300, 150, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2d = bufferedImage.createGraphics();
        
        // Enable anti-aliasing
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        
        // Colors for the banana
        Color bananaYellow = new Color(255, 225, 53);  // Bright yellow
        Color bananaOutline = Color.BLACK;             // Black outline
        
        // Draw a banana bunch (simplified for fallback)
        int centerX = 150;
        int centerY = 75;
        
        // Draw banana
        g2d.setColor(bananaYellow);
        g2d.fillOval(centerX - 60, centerY - 30, 120, 60);
        
        // Draw outline
        g2d.setColor(bananaOutline);
        g2d.setStroke(new BasicStroke(2));
        g2d.drawOval(centerX - 60, centerY - 30, 120, 60);
        
        g2d.dispose();
        
        return new ImageIcon(bufferedImage);
    }
    
    
    //Creates a styled button with the specified text.
    
    private JButton createButton(String text) {
        JButton button = new JButton(text);
        button.setFont(FontManager.getButtonFont());
        button.setBackground(new Color(255, 153, 0)); // Orange button
        button.setForeground(new Color(102,51,0));
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createRaisedBevelBorder());
        button.setPreferredSize(new Dimension(200, 50));
        button.setMaximumSize(new Dimension(200, 50));
        button.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        return button;
    }
    
    //Sets the welcome message with the player's username.
     
    public void setWelcomeMessage(String username) {
        welcomeLabel.setText("Welcome, " + username + "!");
    }
    
     //Updates the welcome message with the player's display name.
    
    public void updateWelcomeMessage(String displayName) {
        welcomeLabel.setText("Welcome, " + displayName + "!");
    }
    
    //Sets the start game button listener.
    
    public void setStartGameButtonListener(ActionListener listener) {
        // Remove existing listeners
        for (ActionListener al : startGameButton.getActionListeners()) {
            startGameButton.removeActionListener(al);
        }
        
        // Add new listener
        startGameButton.addActionListener(listener);
    }
    
    //Sets the profile button listener.
    
    public void setProfileButtonListener(ActionListener listener) {
        // Find the profile button
        for (Component comp : getComponents()) {
            if (comp instanceof JPanel) {
                JPanel panel = (JPanel) comp;
                for (Component button : panel.getComponents()) {
                    if (button instanceof JButton && ((JButton) button).getText().equals("Profile")) {
                        JButton profileButton = (JButton) button;
                        
                        // Remove existing listeners
                        for (ActionListener al : profileButton.getActionListeners()) {
                            profileButton.removeActionListener(al);
                        }
                        
                        // Add new listener
                        profileButton.addActionListener(listener);
                        return;
                    }
                }
            }
        }
    }
    
    //Sets the leaderboard button listener.
     
    public void setLeaderboardButtonListener(ActionListener listener) {
        // Find the leaderboard button
        for (Component comp : getComponents()) {
            if (comp instanceof JPanel) {
                JPanel panel = (JPanel) comp;
                for (Component button : panel.getComponents()) {
                    if (button instanceof JButton && ((JButton) button).getText().equals("Leaderboard")) {
                        JButton leaderboardButton = (JButton) button;
                        
                        // Remove existing listeners
                        for (ActionListener al : leaderboardButton.getActionListeners()) {
                            leaderboardButton.removeActionListener(al);
                        }
                        
                        // Add new listener
                        leaderboardButton.addActionListener(listener);
                        return;
                    }
                }
            }
        }
    }
    
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        
        // Draw a gradient background
        Graphics2D g2d = (Graphics2D) g;
        GradientPaint gradient = new GradientPaint(
            0, 0, new Color(102, 51, 0),
            0, getHeight(), new Color(204, 102, 0)
        );
        g2d.setPaint(gradient);
        g2d.fillRect(0, 0, getWidth(), getHeight());
    }
} 