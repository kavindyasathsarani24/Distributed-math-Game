package com.bananadash.game.utils;

import java.awt.Font;
import java.awt.GraphicsEnvironment;


//Utility class for managing fonts across the Banana Dash game.
 
public class FontManager {
    
    // Font family name
    private static final String PRIMARY_FONT = "Verdana";
    private static final String FALLBACK_FONT = "Dialog";
    
    // Font style constants
    private static final int TITLE_STYLE = Font.BOLD;
    private static final int HEADING_STYLE = Font.BOLD;
    private static final int NORMAL_STYLE = Font.PLAIN;
    private static final int BUTTON_STYLE = Font.BOLD;
    
    // Font size constants
    private static final int TITLE_SIZE = 40;
    private static final int GAME_TITLE_SIZE = 36;
    private static final int HEADING_SIZE = 28;
    private static final int SUBHEADING_SIZE = 24;
    private static final int NORMAL_SIZE = 18;
    private static final int BUTTON_SIZE = 20;
    private static final int SMALL_SIZE = 16;
    
    // Check if font exists, otherwise use fallback
    private static String getFontFamily() {
        String fontFamily = PRIMARY_FONT;
        
        // Get available font family names
        GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
        String[] fontNames = ge.getAvailableFontFamilyNames();
        
        // Check if primary font exists
        boolean primaryFontExists = false;
        for (String name : fontNames) {
            if (name.equalsIgnoreCase(PRIMARY_FONT)) {
                primaryFontExists = true;
                break;
            }
        }
        
        // Use fallback if primary font doesn't exist
        if (!primaryFontExists) {
            fontFamily = FALLBACK_FONT;
        }
        
        return fontFamily;
    }
    
    
    // Returns the main title font used for the game's main title.
     
    public static Font getTitleFont() {
        return new Font(getFontFamily(), TITLE_STYLE, TITLE_SIZE);
    }
    
    
    //Returns the game title font used for "BANANA DASH".
     
    public static Font getGameTitleFont() {
        return new Font(getFontFamily(), HEADING_STYLE, GAME_TITLE_SIZE);
    }

    
    //Returns the heading font used for screen headers.
     
    public static Font getHeadingFont() {
        return new Font(getFontFamily(), HEADING_STYLE, HEADING_SIZE);
    }
    
   
    //Returns the subheading font used for section headers.
    
    public static Font getSubheadingFont() {
        return new Font(getFontFamily(), HEADING_STYLE, SUBHEADING_SIZE);
    }
    
  
    //Returns the normal font used for regular text.
     
    public static Font getNormalFont() {
        return new Font(getFontFamily(), NORMAL_STYLE, NORMAL_SIZE);
    }
    
   
    //Returns the button font used for buttons.
     
    public static Font getButtonFont() {
        return new Font(getFontFamily(), BUTTON_STYLE, BUTTON_SIZE);
    }
    
    
    //Returns the small font used for smaller text elements.
     
    public static Font getSmallFont() {
        return new Font(getFontFamily(), NORMAL_STYLE, SMALL_SIZE);
    }
    
    
    //Returns the small bold font used for smaller emphasized text elements.
    
    public static Font getSmallBoldFont() {
        return new Font(getFontFamily(), HEADING_STYLE, SMALL_SIZE);
    }
} 