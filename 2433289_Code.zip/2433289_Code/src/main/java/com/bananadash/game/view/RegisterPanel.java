package com.bananadash.game.view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import com.bananadash.game.utils.FontManager;


//Registration screen for the Banana Dash game user can register by providing username and password
 
 
public class RegisterPanel extends JPanel {
    private GameFrame parentFrame;
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JPasswordField confirmPasswordField;
    private JLabel statusLabel;
    private JButton registerButton;
    
    //Create new RegisterPanel.
    public RegisterPanel(GameFrame parentFrame) {
        this.parentFrame = parentFrame;
        
        // Set up the panel
        setLayout(new BorderLayout());
        setBackground(new Color(102, 51, 0)); // Brown background
        
        // Create title panel
        JPanel titlePanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        titlePanel.setOpaque(false);
        
        // Create title label
        JLabel titleLabel = new JLabel("Create a New Account");
        titleLabel.setFont(FontManager.getTitleFont());
        titleLabel.setForeground(Color.WHITE);
        titlePanel.add(titleLabel);
        
        // Create form panel with GridBagLayout for better alignment
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setOpaque(false);
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(10, 5, 10, 5);
        
        // Create username field
        JLabel usernameLabel = new JLabel("Username:");
        usernameLabel.setFont(FontManager.getNormalFont());
        usernameLabel.setForeground(Color.WHITE);
        usernameField = new JTextField(20);
        usernameField.setFont(FontManager.getNormalFont());
        
        // Create password field
        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setFont(FontManager.getNormalFont());
        passwordLabel.setForeground(Color.WHITE);
        passwordField = new JPasswordField(20);
        passwordField.setFont(FontManager.getNormalFont());
        
        // Create confirm password field
        JLabel confirmPasswordLabel = new JLabel("Confirm Password:");
        confirmPasswordLabel.setFont(FontManager.getNormalFont());
        confirmPasswordLabel.setForeground(Color.WHITE);
        confirmPasswordField = new JPasswordField(20);
        confirmPasswordField.setFont(FontManager.getNormalFont());
        
        // Add labels and fields to the form with proper alignment
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.EAST;
        formPanel.add(usernameLabel, gbc);
        
        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.WEST;
        formPanel.add(usernameField, gbc);
        
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.anchor = GridBagConstraints.EAST;
        formPanel.add(passwordLabel, gbc);
        
        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.WEST;
        formPanel.add(passwordField, gbc);
        
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.anchor = GridBagConstraints.EAST;
        formPanel.add(confirmPasswordLabel, gbc);
        
        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.WEST;
        formPanel.add(confirmPasswordField, gbc);
        
        // Create buttons panel
        JPanel buttonsPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        buttonsPanel.setOpaque(false);
        
        // Create register button in register panel
        registerButton = new JButton("Register");
        registerButton.setFont(FontManager.getButtonFont());
        registerButton.setBackground(new Color(255, 153, 0)); // Orange button
        registerButton.setForeground(new Color(102,51,0));
        registerButton.setFocusPainted(false);
        registerButton.setBorder(BorderFactory.createRaisedBevelBorder());
        registerButton.setPreferredSize(new Dimension(120, 40));
        registerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                attemptRegistration();
            }
        });
        
        // Create back button in register panel
        JButton backButton = new JButton("Back");
        backButton.setFont(FontManager.getButtonFont());
        backButton.setBackground(new Color(255, 153, 0)); // Orange button
        backButton.setForeground(new Color(102,51,0));
        backButton.setFocusPainted(false);
        backButton.setBorder(BorderFactory.createRaisedBevelBorder());
        backButton.setPreferredSize(new Dimension(120, 40));
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                parentFrame.getGameController().navigateToStartup();
            }
        });
        
        buttonsPanel.add(registerButton);
        buttonsPanel.add(Box.createRigidArea(new Dimension(20, 0)));
        buttonsPanel.add(backButton);
        
        // Create status label
        statusLabel = new JLabel("");
        statusLabel.setFont(FontManager.getNormalFont());
        statusLabel.setForeground(Color.WHITE);
        
        // Add status label to form
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.insets = new Insets(20, 5, 10, 5);
        formPanel.add(statusLabel, gbc);
        
        // Add buttons panel to form
        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.anchor = GridBagConstraints.CENTER;
        formPanel.add(buttonsPanel, gbc);
        
        // Center the form in the screen
        JPanel centeringPanel = new JPanel(new GridBagLayout());
        centeringPanel.setOpaque(false);
        centeringPanel.add(formPanel);
        
        // Add components to the main panel
        add(titlePanel, BorderLayout.NORTH);
        add(centeringPanel, BorderLayout.CENTER);
    }
    
    //Attempts to register a new user
    private void attemptRegistration() {
        // Get the username and passwords
        String username = usernameField.getText();
        String password = new String(passwordField.getPassword());
        String confirmPassword = new String(confirmPasswordField.getPassword());
        
        // Validate new user inputs
        if (username.isEmpty() || password.isEmpty() || confirmPassword.isEmpty()) {
            statusLabel.setText("Please fill in all fields.");
            statusLabel.setForeground(Color.RED);
            return;
        }
        
        if (username.length() < 3) {
            statusLabel.setText("Username must be at least 3 characters long.");
            statusLabel.setForeground(Color.RED);
            return;
        }
        
        if (password.length() < 6) {
            statusLabel.setText("Password must be at least 6 characters long.");
            statusLabel.setForeground(Color.RED);
            return;
        }
        
        if (!password.equals(confirmPassword)) {
            statusLabel.setText("Passwords do not match.");
            statusLabel.setForeground(Color.RED);
            return;
        }
        
        // Set status to "Registering..."
        statusLabel.setText("Registering...");
        statusLabel.setForeground(Color.WHITE);
        
        // The actual registration will be handled by the controller
        
        
        // Clear fields
        usernameField.setText("");
        passwordField.setText("");
        confirmPasswordField.setText("");
    }
    
    //Display error message when status is error
    public void setStatus(String message, boolean isError) {
        statusLabel.setText(message);
        statusLabel.setForeground(isError ? Color.RED : Color.GREEN);
    }
    
    //get username
    public String getUsername() {
        return usernameField.getText();
    }
    
    //get password
    public String getPassword() {
        return new String(passwordField.getPassword());
    }
    
    //Resets the form fields and status.
    public void resetForm() {
        usernameField.setText("");
        passwordField.setText("");
        confirmPasswordField.setText("");
        statusLabel.setText("");
    }
    
    //Sets the submit button action listener.
    public void setSubmitButtonListener(ActionListener listener) {
        // Remove existing listeners
        for (ActionListener al : registerButton.getActionListeners()) {
            registerButton.removeActionListener(al);
        }
        
        // Add new listener
        registerButton.addActionListener(listener);
    }
    
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        
        // Draw a gradient background
        Graphics2D g2d = (Graphics2D) g;
        GradientPaint gradient = new GradientPaint(
            0, 0, new Color(102, 51, 0),
            0, getHeight(), new Color(204, 102, 0)
        );
        g2d.setPaint(gradient);
        g2d.fillRect(0, 0, getWidth(), getHeight());
    }
} 