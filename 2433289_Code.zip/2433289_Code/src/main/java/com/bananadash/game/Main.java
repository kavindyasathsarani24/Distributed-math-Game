package com.bananadash.game;

import com.bananadash.game.controller.GameController;
import com.bananadash.game.model.DatabaseManager;
import com.bananadash.game.view.GameFrame;


//Main entry point for the Banana Dash game.

public class Main {
    public static void main(String[] args) {
        System.out.println("Starting Banana Dash Game...");
        
        try {
            // Set look and feel to system default
            javax.swing.UIManager.setLookAndFeel(
                javax.swing.UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            System.err.println("Failed to set look and feel: " + e.getMessage());
        }
        
        // Initialize database
        DatabaseManager databaseManager = new DatabaseManager();
        databaseManager.initializeDatabase();
        
        // Create the main game frame
        GameFrame gameFrame = new GameFrame("Banana Dash");
        
        // Create and start the game controller
        // The GameController initialize the LeaderboardModel and LeaderboardController
        GameController gameController = new GameController(gameFrame, databaseManager);
        
        // Set the controller in the frame
        gameFrame.setGameController(gameController);
        
        // Start the game
        gameController.start();
    }
} 