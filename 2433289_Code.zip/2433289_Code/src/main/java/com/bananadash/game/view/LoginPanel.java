package com.bananadash.game.view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import com.bananadash.game.utils.FontManager;

//The login screen for the Banana Dash game.

public class LoginPanel extends JPanel {
    private GameFrame parentFrame;
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JLabel statusLabel;
    private JButton loginButton;
    
    //Creates a new LoginPanel.
     
    public LoginPanel(GameFrame parentFrame) {
        this.parentFrame = parentFrame;
        
        // Set up the panel
        setLayout(new BorderLayout());
        setBackground(new Color(102, 51, 0)); // Brown background
        
        // Create title panel
        JPanel titlePanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        titlePanel.setOpaque(false);
        
        // Create title label
        JLabel titleLabel = new JLabel("Login");
        titleLabel.setFont(FontManager.getTitleFont());
        titleLabel.setForeground(Color.WHITE);
        titlePanel.add(titleLabel);
        
        // Create form panel with GridBagLayout for better alignment
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setOpaque(false);
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(10, 5, 10, 5);
        
        // Create username field
        JLabel usernameLabel = new JLabel("Username:");
        usernameLabel.setFont(FontManager.getNormalFont());
        usernameLabel.setForeground(Color.WHITE);
        usernameField = new JTextField(20);
        usernameField.setFont(FontManager.getNormalFont());
        
        // Create password field
        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setFont(FontManager.getNormalFont());
        passwordLabel.setForeground(Color.WHITE);
        passwordField = new JPasswordField(20);
        passwordField.setFont(FontManager.getNormalFont());
        
        // Add components to the form panel with proper alignment
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.EAST;
        formPanel.add(usernameLabel, gbc);
        
        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.WEST;
        formPanel.add(usernameField, gbc);
        
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.anchor = GridBagConstraints.EAST;
        formPanel.add(passwordLabel, gbc);
        
        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.WEST;
        formPanel.add(passwordField, gbc);
        
        // Create buttons panel
        JPanel buttonsPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        buttonsPanel.setOpaque(false);
        
        // Create login button
        loginButton = new JButton("Login");
        loginButton.setFont(FontManager.getButtonFont());
        loginButton.setBackground(new Color(255, 153, 0)); // Orange button
        loginButton.setForeground(new Color(102,51,0));
        loginButton.setFocusPainted(false);
        loginButton.setBorder(BorderFactory.createRaisedBevelBorder());
        loginButton.setPreferredSize(new Dimension(120, 40));
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                attemptLogin();
            }
        });
        
        // Create back button
        JButton backButton = new JButton("Back");
        backButton.setFont(FontManager.getButtonFont());
        backButton.setBackground(new Color(255, 153, 0)); // Orange button
        backButton.setForeground(new Color(102,51,0));
        backButton.setFocusPainted(false);
        backButton.setBorder(BorderFactory.createRaisedBevelBorder());
        backButton.setPreferredSize(new Dimension(120, 40));
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                parentFrame.getGameController().navigateToStartup();
            }
        });
        
        buttonsPanel.add(loginButton);
        buttonsPanel.add(Box.createRigidArea(new Dimension(20, 0)));
        buttonsPanel.add(backButton);
        
        // Create status label
        statusLabel = new JLabel("");
        statusLabel.setFont(FontManager.getNormalFont());
        statusLabel.setForeground(Color.WHITE);
        
        // Add status label to form
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.insets = new Insets(20, 5, 10, 5);
        formPanel.add(statusLabel, gbc);
        
        // Add buttons panel to form
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.anchor = GridBagConstraints.CENTER;
        formPanel.add(buttonsPanel, gbc);
        
        // Center the form in the screen
        JPanel centeringPanel = new JPanel(new GridBagLayout());
        centeringPanel.setOpaque(false);
        centeringPanel.add(formPanel);
        
        // Add components to the main panel
        add(titlePanel, BorderLayout.NORTH);
        add(centeringPanel, BorderLayout.CENTER);
    }
    
    
    //Attempts to log in with the provided credentials.
     
    private void attemptLogin() {
        // Get the username and password
        String username = usernameField.getText();
        String password = new String(passwordField.getPassword());
        
        // Validate input
        if (username.isEmpty() || password.isEmpty()) {
            statusLabel.setText("Please enter both username and password.");
            statusLabel.setForeground(Color.RED);
            return;
        }
        
        // Set status to "Logging in..."
        statusLabel.setText("Logging in...");
        statusLabel.setForeground(Color.WHITE);
        
        
        // Clear fields
        usernameField.setText("");
        passwordField.setText("");
    }
    
   
    //Sets the status message.
    
    public void setStatus(String message, boolean isError) {
        statusLabel.setText(message);
        statusLabel.setForeground(isError ? Color.RED : Color.GREEN);
    }
    
    
    //Gets the username entered by the user.
    
    public String getUsername() {
        return usernameField.getText();
    }
    
    
    //Gets the password entered by the user.
     
    public String getPassword() {
        return new String(passwordField.getPassword());
    }
    
    
    //Resets the form fields and status.
     
    public void resetForm() {
        usernameField.setText("");
        passwordField.setText("");
        statusLabel.setText("");
    }
    
    
    //Sets the submit button action listener.
    
    public void setSubmitButtonListener(ActionListener listener) {
        // Remove existing listeners
        for (ActionListener al : loginButton.getActionListeners()) {
            loginButton.removeActionListener(al);
        }
        
        // Add new listener
        loginButton.addActionListener(listener);
    }
    
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        
        // Draw a gradient background
        Graphics2D g2d = (Graphics2D) g;
        GradientPaint gradient = new GradientPaint(
            0, 0, new Color(102, 51, 0),
            0, getHeight(), new Color(204, 102, 0)
        );
        g2d.setPaint(gradient);
        g2d.fillRect(0, 0, getWidth(), getHeight());
    }
} 