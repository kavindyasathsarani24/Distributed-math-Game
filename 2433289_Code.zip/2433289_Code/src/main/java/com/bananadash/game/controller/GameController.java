package com.bananadash.game.controller;

import com.bananadash.game.model.DatabaseManager;
import com.bananadash.game.model.GameModel;
import com.bananadash.game.model.LeaderboardModel;
import com.bananadash.game.model.Player;
import com.bananadash.game.model.UserSession;
import com.bananadash.game.view.GameFrame;
import com.bananadash.game.view.GamePanel;
import com.bananadash.game.view.LevelCompletePanel;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.List;
import java.util.Map;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;


//The main controller for the Banana Dash game.

public class GameController {
    private GameFrame gameFrame;
    private DatabaseManager databaseManager;
    private GameModel gameModel;
    private Player currentPlayer;
    private SessionController sessionController;
    private UserSession currentSession;
    private LeaderboardModel leaderboardModel;
    private LeaderboardController leaderboardController;
    
    
    //Creates a new GameController.
    
    public GameController(GameFrame gameFrame, DatabaseManager databaseManager) {
        this.gameFrame = gameFrame;
        this.databaseManager = databaseManager;
        this.sessionController = new SessionController(databaseManager);
        
        // Initialize leaderboard components
        this.leaderboardModel = new LeaderboardModel(databaseManager);
        this.leaderboardController = new LeaderboardController(
            leaderboardModel, 
            gameFrame.getLeaderboardPanel()
        );
        
        // Add window listener to handle closing
        gameFrame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                // End current session if exists
                if (currentSession != null) {
                    sessionController.endSession(currentSession.getSessionId());
                }
                
                // Shutdown session controller
                sessionController.shutdown();
                
                // Close database connection
                databaseManager.closeConnection();
            }
        });
        
        // Set up event handlers
        setupEventHandlers();
    }
    
    //Set event handlers for the game.
     
    private void setupEventHandlers() {
        // Login panel
        gameFrame.getLoginPanel().setSubmitButtonListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                handleLogin();
            }
        });
        
        // Register panel
        gameFrame.getRegisterPanel().setSubmitButtonListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                handleRegistration();
            }
        });
        
        // Home panel - Start Game button
        gameFrame.getHomePanel().setStartGameButtonListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                startGame();
            }
        });
        
        // Home panel - Profile button
        gameFrame.getHomePanel().setProfileButtonListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (validateSession()) {
                    updateProfilePanel();
                    gameFrame.showPanel("profile");
                }
            }
        });
        
        // Home panel - Leaderboard button
        gameFrame.getHomePanel().setLeaderboardButtonListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (validateSession()) {
                    leaderboardController.refreshLeaderboard();
                    gameFrame.showPanel("leaderboard");
                }
            }
        });
        
        // Leaderboard panel - Refresh button
        gameFrame.getLeaderboardPanel().setRefreshButtonListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                updateLeaderboard();
            }
        });
        
        // Game panel
        GamePanel gamePanel = gameFrame.getGamePanel();
        gamePanel.setSubmitButtonListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                handleAnswerSubmission();
            }
        });
        
        gamePanel.setHintButtonListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                handleHintRequest();
            }
        });
        
        gamePanel.setUiTimerListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                updateGameTimer();
            }
        });
        
        // Level complete panel
        LevelCompletePanel levelCompletePanel = gameFrame.getLevelCompletePanel();
        levelCompletePanel.setNextLevelButtonListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                startNextLevel();
            }
        });
    }
    
    
    //Starts the game.
     
    public void start() {
        // Show the startup panel
        gameFrame.showPanel("startup");
    }
    
   
    //Handles user login.
    
    private void handleLogin() {
        String username = gameFrame.getLoginPanel().getUsername();
        String password = gameFrame.getLoginPanel().getPassword();
        
        if (username.isEmpty() || password.isEmpty()) {
            gameFrame.getLoginPanel().setStatus("Please enter both username and password", true);
            return;
        }
        
        // Hash the password
        String passwordHash = hashPassword(password);
        
        // Authenticate user
        int userId = databaseManager.authenticateUser(username, passwordHash);
        
        if (userId > 0) {
            // Authentication successful
            gameFrame.getLoginPanel().setStatus("Login successful!", false);
            gameFrame.getLoginPanel().resetForm();  // Reset form fields
            
            // Create user session
            currentSession = sessionController.createSession(userId, username);
            
            // Get user profile
            Map<String, Object> profile = databaseManager.getUserProfile(userId);
            
            if (profile != null) {
                String displayName = (String) profile.get("displayName");
                int currentLevel = (int) profile.get("currentLevel");
                int totalScore = (int) profile.get("totalScore");
                
                // Create player object
                currentPlayer = new Player(userId, username, displayName, currentLevel, totalScore);
                
                // Set the leaderboard model for the player
                currentPlayer.setLeaderboardModel(leaderboardModel);
                
                // Update the leaderboard controller with the current player
                leaderboardController.setCurrentPlayer(currentPlayer);
                
                // Update profile panel with session history
                updateProfilePanel();
                
                // Initialize leaderboard
                updateLeaderboard();
                
                // Show home panel
                gameFrame.showPanel("home");
                gameFrame.getHomePanel().updateWelcomeMessage(displayName);
            }
        } else {
            // Authentication failed
            gameFrame.getLoginPanel().setStatus("Invalid username or password", true);
        }
    }
    
    
    //Handles user registration.
    
    private void handleRegistration() {
        String username = gameFrame.getRegisterPanel().getUsername();
        String password = gameFrame.getRegisterPanel().getPassword();
        
        // Validate input (already done in the view, but double-check here)
        if (username.length() < 3) {
            gameFrame.getRegisterPanel().setStatus("Username must be at least 3 characters long.", true);
            return;
        }
        
        if (password.length() < 6) {
            gameFrame.getRegisterPanel().setStatus("Password must be at least 6 characters long.", true);
            return;
        }
        
        // Hash the password
        String passwordHash = hashPassword(password);
        
        // Register user
        boolean success = databaseManager.registerUser(username, passwordHash);
        
        if (success) {
            // Registration successful
            gameFrame.getRegisterPanel().setStatus("Registration successful! You can now login.", false);
            gameFrame.getRegisterPanel().resetForm();  // Reset form fields
            
            // Show login screen after a delay
            new Thread(() -> {
                try {
                    Thread.sleep(2000);
                    SwingUtilities.invokeLater(() -> {
                        gameFrame.showPanel("login");
                    });
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            }).start();
        } else {
            // Registration failed
            gameFrame.getRegisterPanel().setStatus("Username already exists or registration failed.", true);
        }
    }
    
    
    //Log out the current user.
    
    public void logout() {
        if (currentSession != null) {
            sessionController.endSession(currentSession.getSessionId());
            currentSession = null;
        }
        
        currentPlayer = null;
        gameFrame.showPanel("startup");
    }
    
  
    //Checks if the current session is valid.
     
    private boolean validateSession() {
        if (currentSession == null) {
            return false;
        }
        
        boolean isValid = sessionController.validateSession(currentSession.getSessionId());
        
        if (!isValid) {
            // Session expired, show login screen
            JOptionPane.showMessageDialog(gameFrame, 
                "Your session has expired. Please log in again.", 
                "Session Expired", 
                JOptionPane.WARNING_MESSAGE);
            
            currentSession = null;
            currentPlayer = null;
            gameFrame.showPanel("login");
        }
        
        return isValid;
    }
    
    
    //Starts the game.
    
    private void startGame() {
        // Validate session before starting game
        if (!validateSession()) {
            return;
        }
        
        // Create a new game model if needed
        if (gameModel == null && currentPlayer != null) {
            gameModel = new GameModel(currentPlayer, databaseManager);
        }
        
        // Start the game
        if (gameModel != null) {
            // Start the first level
            gameModel.startLevel();
            
            // Update the game panel
            GamePanel gamePanel = gameFrame.getGamePanel();
            gamePanel.setLevel(currentPlayer.getCurrentLevel());
            gamePanel.setTimer(gameModel.getTimeRemaining(), currentPlayer.getCurrentLevelTimeLimit());
            gamePanel.setPuzzleImage(gameModel.getCurrentPuzzleImage());
            gamePanel.clearAnswer();
            
            // Set up the UI timer
            gamePanel.setUiTimerListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    updateGameTimer();
                }
            });
            
            // Set up the submit button
            gamePanel.setSubmitButtonListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    handleAnswerSubmission();
                }
            });
            
            // Set up the hint button
            gamePanel.setHintButtonListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    handleHintRequest();
                }
            });
            
            // Start the game timer
            gamePanel.startGame();
            
            // Show the game panel
            gameFrame.showPanel("game");
        }
    }
    
    
    //Updates the game timer.
     
    private void updateGameTimer() {
        if (gameModel != null && gameModel.isGameActive()) {
            // Update the game model
            boolean gameActive = gameModel.update();
            
            // Update the UI
            GamePanel gamePanel = gameFrame.getGamePanel();
            gamePanel.setTimer(gameModel.getTimeRemaining(), currentPlayer.getCurrentLevelTimeLimit());
            
            // Check if the game is over
            if (!gameActive) {
                // Stop the game timer
                gamePanel.stopGame();
                
                // Show game over message
                JOptionPane.showMessageDialog(
                    gameFrame,
                    "Time's up! Game over.",
                    "Game Over",
                    JOptionPane.INFORMATION_MESSAGE
                );
                
                // Return to home screen
                gameFrame.showPanel("home");
            }
        }
    }
    
   
    //Handles answer submission.
    
    private void handleAnswerSubmission() {
        // Validate session before processing answer
        if (!validateSession()) {
            return;
        }
        
        if (gameModel != null && gameModel.isGameActive()) {
            // Get the answer from the game panel
            GamePanel gamePanel = gameFrame.getGamePanel();
            int answer;
            try {
                answer = gamePanel.getAnswer();
            } catch (NumberFormatException e) {
                // Invalid input
                JOptionPane.showMessageDialog(
                    gameFrame,
                    "Please enter a valid number.",
                    "Invalid Input",
                    JOptionPane.ERROR_MESSAGE
                );
                return;
            }
            
            // Validate the answer
            boolean correct = gameModel.validateAnswer(answer);
            
            if (correct) {
                // Stop the game timer
                gamePanel.stopGame();
                
                // Get the score for this level
                int score = gameModel.getPlayer().calculateScore(gameModel.getTimeRemaining());
                
                // Update the UI with new score
                gamePanel.updateScore(currentPlayer.getTotalScore());
                updateProfilePanel();
                updateLeaderboard();
                
                // Show level complete panel
                LevelCompletePanel levelCompletePanel = gameFrame.getLevelCompletePanel();
                levelCompletePanel.updateLevelInfo(
                    currentPlayer.getCurrentLevel() - 1, // We've already advanced to the next level
                    currentPlayer.getCurrentLevelTimeLimit() - gameModel.getTimeRemaining(),
                    score  // Pass the score for this level
                );
                
                // Set up the next level button
                levelCompletePanel.setNextLevelButtonListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        startNextLevel();
                    }
                });
                
                // Show the level complete panel
                gameFrame.showPanel("levelComplete");
            } else {
                // Show incorrect answer message
                JOptionPane.showMessageDialog(
                    gameFrame,
                    "Incorrect answer. Try again!",
                    "Incorrect",
                    JOptionPane.ERROR_MESSAGE
                );
            }
        }
    }
    
    //Handles hint request.
     
    private void handleHintRequest() {
        // Validate session before providing hint
        if (!validateSession()) {
            return;
        }
        
        if (gameModel != null) {
            String hint = gameModel.getHint();
            gameFrame.getGamePanel().showHint(hint);
            
            // Update score display after hint penalty
            gameFrame.getGamePanel().updateScore(currentPlayer.getTotalScore());
        }
    }
    
    
    //Starts the next level.
     
    private void startNextLevel() {
        startGame();
        // Update score display for new level
        gameFrame.getGamePanel().updateScore(currentPlayer.getTotalScore());
    }
    
   
    //Hashes a password using SHA-256.
    
    private String hashPassword(String password) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(password.getBytes());
            
            // Convert to hex string
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) {
                    hexString.append('0');
                }
                hexString.append(hex);
            }
            
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            System.err.println("Error hashing password: " + e.getMessage());
            return password; // Fallback to plain text (not secure)
        }
    }
    
 
    //Updates the profile panel with user data.
    
    private void updateProfilePanel() {
        if (currentPlayer != null) {
            // Get user profile data
            Map<String, Object> profileData = databaseManager.getUserProfile(currentPlayer.getUserId());
            
            // Update profile information
            gameFrame.getProfilePanel().updateProfile(profileData);
        }
        
        // Update the leaderboard controller with the current player
        leaderboardController.setCurrentPlayer(currentPlayer);
    }
    
   
    //Updates the leaderboard.
     
    private void updateLeaderboard() {
        leaderboardController.refreshLeaderboard();
    }
    
    
    //Navigates to the login panel and reset the form.
     
    public void navigateToLogin() {
        gameFrame.getLoginPanel().resetForm();
        gameFrame.showPanel("login");
    }
    
   
     // Navigates to the register panel and reset the form.
     
    public void navigateToRegister() {
        gameFrame.getRegisterPanel().resetForm();
        gameFrame.showPanel("register");
    }
    
    
    //Navigates to the startup panel and reset all forms.
     
    public void navigateToStartup() {
        gameFrame.getLoginPanel().resetForm();
        gameFrame.getRegisterPanel().resetForm();
        gameFrame.showPanel("startup");
    }
} 