package com.bananadash.game.utils;

import javax.imageio.ImageIO;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;


//Utility class for loading images.
 
public class ImageLoader {
    
    //Loads an image from the resources folder.
    
    public static BufferedImage loadImage(String path) {
        try {
            InputStream is = ImageLoader.class.getClassLoader().getResourceAsStream(path);
            if (is != null) {
                return ImageIO.read(is);
            } else {
                System.err.println("Could not find image: " + path);
                return null;
            }
        } catch (IOException e) {
            System.err.println("Error loading image: " + e.getMessage());
            return null;
        }
    }
    
    //Loads and scales an image from the resources folder.
     
    public static Image loadAndScaleImage(String path, int width, int height) {
        BufferedImage original = loadImage(path);
        if (original != null) {
            return original.getScaledInstance(width, height, Image.SCALE_SMOOTH);
        }
        return null;
    }
} 