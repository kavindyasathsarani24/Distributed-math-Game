package com.bananadash.game.view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

//The main window frame for the Banana Dash game.

public class GameFrame extends JFrame {
    private CardLayout cardLayout;
    private JPanel contentPanel;
    private com.bananadash.game.controller.GameController gameController;
    
    // Panels for different screens
    private StartupPanel startupPanel;
    private LoginPanel loginPanel;
    private RegisterPanel registerPanel;
    private HomePanel homePanel;
    private ProfilePanel profilePanel;
    private LeaderboardPanel leaderboardPanel;
    private GamePanel gamePanel;
    private LevelCompletePanel levelCompletePanel;
    
    
    //Creates a new GameFrame with the specified title.
    
    public GameFrame(String title) {
        super(title);
        
        // Set up the frame
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 600);
        setLocationRelativeTo(null);
        setResizable(false);
        
        // Create card layout for switching between panels
        cardLayout = new CardLayout();
        contentPanel = new JPanel(cardLayout);
        
        // Initialize panels
        initializePanels();
        
        // Add panels to the content panel
        contentPanel.add(startupPanel, "startup");
        contentPanel.add(loginPanel, "login");
        contentPanel.add(registerPanel, "register");
        contentPanel.add(homePanel, "home");
        contentPanel.add(profilePanel, "profile");
        contentPanel.add(leaderboardPanel, "leaderboard");
        contentPanel.add(gamePanel, "game");
        contentPanel.add(levelCompletePanel, "levelComplete");
        
        // Show the startup panel initially
        cardLayout.show(contentPanel, "startup");
        
        // Add the content panel to the frame
        add(contentPanel);
        
        // Add window listener to handle closing
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                // Perform cleanup before closing
                System.out.println("Game window closing...");
            }
        });
        
        // Make the frame visible
        setVisible(true);
    }
    
    
    //Initializes all the panels for the game.
    
    private void initializePanels() {
        startupPanel = new StartupPanel(this);
        loginPanel = new LoginPanel(this);
        registerPanel = new RegisterPanel(this);
        homePanel = new HomePanel(this);
        profilePanel = new ProfilePanel(this);
        leaderboardPanel = new LeaderboardPanel(this);
        gamePanel = new GamePanel(this);
        levelCompletePanel = new LevelCompletePanel(this);
    }
    
    
    //Shows the specified panel.
    
    public void showPanel(String panelName) {
        cardLayout.show(contentPanel, panelName);
    }
    
    
    //Gets the startup panel.
    
    public StartupPanel getStartupPanel() {
        return startupPanel;
    }
    
    //Gets the login panel.
    
    public LoginPanel getLoginPanel() {
        return loginPanel;
    }
    
    
    //Gets the register panel.
    
    public RegisterPanel getRegisterPanel() {
        return registerPanel;
    }
    
   
    //Gets the home panel.
    
    public HomePanel getHomePanel() {
        return homePanel;
    }
    
   
    //Gets the profile panel.
     
    public ProfilePanel getProfilePanel() {
        return profilePanel;
    }
    
    //Gets the leaderboard panel.
     
    public LeaderboardPanel getLeaderboardPanel() {
        return leaderboardPanel;
    }
    
    
    //Gets the game panel.
   
    public GamePanel getGamePanel() {
        return gamePanel;
    }
    
    
    //Gets the level complete panel.
    
    public LevelCompletePanel getLevelCompletePanel() {
        return levelCompletePanel;
    }
    
    
    //Gets the game controller.
   
    public com.bananadash.game.controller.GameController getGameController() {
        return gameController;
    }
    
    
    //Sets the game controller.
     
    public void setGameController(com.bananadash.game.controller.GameController controller) {
        this.gameController = controller;
    }
} 