package com.bananadash.game.view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


//The level complete screen for the Banana Dash game.
 
public class LevelCompletePanel extends JPanel {
    private GameFrame parentFrame;
    private JLabel levelLabel;
    private JLabel timeLabel;
    private JLabel scoreLabel;
    private JButton nextLevelButton;
    private JButton homeButton;
    
    
    //Creates a new LevelCompletePanel.
    
    public LevelCompletePanel(GameFrame parentFrame) {
        this.parentFrame = parentFrame;
        
        // Set up the panel
        setLayout(new BorderLayout());
        setBackground(new Color(102, 51, 0)); // Brown background
        
        // Create title panel
        JPanel titlePanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        titlePanel.setOpaque(false);
        
        // Create title label
        JLabel titleLabel = new JLabel("Level Complete!");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 36));
        titleLabel.setForeground(Color.WHITE);
        titlePanel.add(titleLabel);
        
        // Create results panel
        JPanel resultsPanel = new JPanel();
        resultsPanel.setLayout(new BoxLayout(resultsPanel, BoxLayout.Y_AXIS));
        resultsPanel.setOpaque(false);
        resultsPanel.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        // Create level label
        levelLabel = new JLabel("Level 1 Completed");
        levelLabel.setFont(new Font("Arial", Font.BOLD, 24));
        levelLabel.setForeground(Color.WHITE);
        levelLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        // Create time label
        timeLabel = new JLabel("Time Taken: 0s");
        timeLabel.setFont(new Font("Arial", Font.PLAIN, 20));
        timeLabel.setForeground(Color.WHITE);
        timeLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        // Create score label
        scoreLabel = new JLabel("Score: 0");
        scoreLabel.setFont(new Font("Arial", Font.PLAIN, 20));
        scoreLabel.setForeground(Color.WHITE);
        scoreLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        // Add labels to results panel
        resultsPanel.add(Box.createVerticalGlue());
        resultsPanel.add(levelLabel);
        resultsPanel.add(Box.createRigidArea(new Dimension(0, 20)));
        resultsPanel.add(timeLabel);
        resultsPanel.add(Box.createRigidArea(new Dimension(0, 10)));
        resultsPanel.add(scoreLabel);
        resultsPanel.add(Box.createVerticalGlue());
        
        // Create buttons panel
        JPanel buttonsPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        buttonsPanel.setOpaque(false);
        
        // Create next level button
        nextLevelButton = new JButton("Next Level");
        nextLevelButton.setFont(new Font("Arial", Font.BOLD, 16));
        nextLevelButton.setBackground(new Color(255, 153, 0)); // Orange button
        nextLevelButton.setForeground(new Color(102,51,0));
        nextLevelButton.setFocusPainted(false);
        nextLevelButton.setBorder(BorderFactory.createRaisedBevelBorder());
        nextLevelButton.setPreferredSize(new Dimension(150, 40));
        
        // Create home button
        homeButton = new JButton("Back to Home");
        homeButton.setFont(new Font("Arial", Font.BOLD, 16));
        homeButton.setBackground(new Color(255, 153, 0)); // Gray button
        homeButton.setForeground(new Color(102,51,0));
        homeButton.setFocusPainted(false);
        homeButton.setBorder(BorderFactory.createRaisedBevelBorder());
        homeButton.setPreferredSize(new Dimension(150, 40));
        homeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                parentFrame.showPanel("home");
            }
        });
        
        buttonsPanel.add(nextLevelButton);
        buttonsPanel.add(Box.createRigidArea(new Dimension(20, 0)));
        buttonsPanel.add(homeButton);
        
        // Add components to the main panel
        add(titlePanel, BorderLayout.NORTH);
        add(resultsPanel, BorderLayout.CENTER);
        add(buttonsPanel, BorderLayout.SOUTH);
    }
    
    
    //Updates the level complete information.
      
     
    public void updateLevelInfo(int level, int timeTaken, int score) {
        levelLabel.setText("Level " + level + " Completed");
        timeLabel.setText("Time Taken: " + timeTaken + "s");
        scoreLabel.setText("Score: " + score);
    }
    
    
    //Sets the next level button action listener.
     
    public void setNextLevelButtonListener(ActionListener listener) {
        // Remove existing listeners
        for (ActionListener al : nextLevelButton.getActionListeners()) {
            nextLevelButton.removeActionListener(al);
        }
        
        // Add new listener
        nextLevelButton.addActionListener(listener);
    }
    
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        
        // Draw a gradient background
        Graphics2D g2d = (Graphics2D) g;
        GradientPaint gradient = new GradientPaint(
            0, 0, new Color(102, 51, 0),
            0, getHeight(), new Color(204, 102, 0)
        );
        g2d.setPaint(gradient);
        g2d.fillRect(0, 0, getWidth(), getHeight());
        
        // Draw celebratory particles
        drawCelebration(g2d);
    }
    
    
    //Draws celebratory particles on the background.
     
    private void drawCelebration(Graphics2D g2d) {
        // Draw confetti-like particles
        for (int i = 0; i < 100; i++) {
            int x = (int) (Math.random() * getWidth());
            int y = (int) (Math.random() * getHeight());
            int size = 5 + (int) (Math.random() * 10);
            
            // Random colors for confetti
            Color[] colors = {
                new Color(255, 0, 0, 150),   // Red
                new Color(0, 255, 0, 150),   // Green
                new Color(0, 0, 255, 150),   // Blue
                new Color(255, 255, 0, 150), // Yellow
                new Color(255, 0, 255, 150), // Magenta
                new Color(0, 255, 255, 150)  // Cyan
            };
            
            g2d.setColor(colors[(int) (Math.random() * colors.length)]);
            
            // Draw different shapes for variety
            int shapeType = (int) (Math.random() * 3);
            switch (shapeType) {
                case 0:
                    g2d.fillRect(x, y, size, size); // Square
                    break;
                case 1:
                    g2d.fillOval(x, y, size, size); // Circle
                    break;
                case 2:
                    // Triangle
                    int[] xPoints = {x, x + size / 2, x + size};
                    int[] yPoints = {y + size, y, y + size};
                    g2d.fillPolygon(xPoints, yPoints, 3);
                    break;
            }
        }
    }
} 