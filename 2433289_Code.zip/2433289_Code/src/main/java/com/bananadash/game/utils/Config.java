package com.bananadash.game.utils;

import java.awt.Color;
import java.awt.Font;


//Configuration class for global game settings.
 
public class Config {
    // Database settings
    public static final String DB_NAME = "database/game_data.db";
    
    // API settings
    public static final String BANANA_API_URL = "http://marcconrad.com/uob/banana/api.php";
    
    // UI settings
    public static final int WINDOW_WIDTH = 800;
    public static final int WINDOW_HEIGHT = 600;
    
    // Color scheme
    public static final Color PRIMARY_COLOR = new Color(25, 118, 210); // Blue
    public static final Color SECONDARY_COLOR = new Color(13, 71, 161); // Dark Blue
    public static final Color ACCENT_COLOR = new Color(255, 153, 0);   // Orange
    public static final Color TEXT_COLOR = Color.WHITE;
    public static final Color BUTTON_COLOR = new Color(255, 153, 0);   // Orange
    public static final Color TIMER_GREEN = new Color(76, 175, 80);    // Green
    public static final Color TIMER_YELLOW = new Color(255, 235, 59);  // Yellow
    public static final Color TIMER_RED = new Color(244, 67, 54);      // Red
    
    // Font settings
    public static final Font TITLE_FONT = new Font("Arial", Font.BOLD, 36);
    public static final Font HEADING_FONT = new Font("Arial", Font.BOLD, 24);
    public static final Font NORMAL_FONT = new Font("Arial", Font.PLAIN, 16);
    public static final Font BUTTON_FONT = new Font("Arial", Font.BOLD, 16);
    
    // Game settings
    public static final int INITIAL_TIME_LIMIT = 120; // seconds
    public static final int HINT_PENALTY = 50;        // points
    public static final int BASE_POINTS = 100;        // points for correct answer
    public static final int TIME_BONUS_MULTIPLIER = 10; // points per second remaining
    public static final int STREAK_BONUS_MULTIPLIER = 20; // points per consecutive correct answer
    public static final int LEVEL_BONUS_MULTIPLIER = 50;  // points per level
    
    // Timer settings
    public static final int TIMER_UPDATE_INTERVAL = 100; // milliseconds
    
    private Config() {
        
    }
} 