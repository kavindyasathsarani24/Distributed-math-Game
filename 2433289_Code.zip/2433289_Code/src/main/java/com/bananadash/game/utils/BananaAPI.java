package com.bananadash.game.utils;

import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.net.URL;
import java.util.Base64;


//Handles interactions with the Banana API for puzzles.
 
public class BananaAPI {
    private static final String BASE_URL = "http://marcconrad.com/uob/banana/api.php";
    
   
    //Fetch a puzzle from the Banana API.
    
    public JSONObject getPuzzle(boolean useBase64) {
        String apiUrl = BASE_URL + "?out=json";
        if (useBase64) {
            apiUrl += "&base64=yes";
        }
        
        try (CloseableHttpClient httpClient = HttpClients.createDefault()) {
            HttpGet request = new HttpGet(apiUrl);
            
            try (CloseableHttpResponse response = httpClient.execute(request)) {
                HttpEntity entity = response.getEntity();
                if (entity != null) {
                    String result = EntityUtils.toString(entity);
                    JSONObject jsonResult = new JSONObject(result);
                    System.out.println("API Response: " + jsonResult.toString().substring(0, Math.min(100, jsonResult.toString().length())) + "...");
                    return jsonResult;
                }
            }
        } catch (IOException e) {
            System.err.println("Error fetching puzzle: " + e.getMessage());
        }
        
        return null;
    }
    
    
    //Load a puzzle image from either a URL or base64 data.
     
    public BufferedImage loadPuzzleImage(JSONObject puzzleData) {
        try {
            // Print the keys available in the puzzle data
            System.out.println("Available keys in puzzle data: " + puzzleData.keySet());
            
            BufferedImage image = null;
            
            // Try to load from question field first
            if (puzzleData.has("question")) {
                String questionValue = puzzleData.getString("question");
                
                // Check if the question field contains base64 data
                if (questionValue.startsWith("data:image") || questionValue.startsWith("iVBOR")) {
                    System.out.println("Detected base64 image in question field");
                    image = Base64ImageDecoder.decodeToImage(questionValue);
                    if (image != null) {
                        System.out.println("Successfully loaded image from base64 data in question field");
                        return image;
                    }
                } else {
                    // Try to load from URL
                    System.out.println("Attempting to load image from URL: " + questionValue);
                    try {
                        URL url = new URL(questionValue);
                        image = ImageIO.read(url);
                        if (image != null) {
                            System.out.println("Successfully loaded image from URL");
                            return image;
                        } else {
                            System.err.println("Failed to load image from URL");
                        }
                    } catch (IOException e) {
                        System.err.println("Error loading image from URL: " + e.getMessage());
                    }
                }
            }
            
            
            if (puzzleData.has("base64")) {
                System.out.println("Attempting to load image from base64 field");
                String base64String = puzzleData.getString("base64");
                image = Base64ImageDecoder.decodeToImage(base64String);
                if (image != null) {
                    System.out.println("Successfully loaded image from base64 field");
                    return image;
                }
            }
            
            
            System.err.println("Puzzle data missing required image fields or all loading methods failed");
            
        } catch (Exception e) {
            System.err.println("Unexpected error loading puzzle image: " + e.getMessage());
            e.printStackTrace();
        }
        
        return null;
    }
    
   
    //Validate a user's answer against the correct solution.
    
    public boolean validateAnswer(int userAnswer, JSONObject puzzleData) {
        if (puzzleData != null && puzzleData.has("solution")) {
            int correctAnswer = puzzleData.getInt("solution");
            return userAnswer == correctAnswer;
        }
        return false;
    }
} 