package com.bananadash.game.model;

import java.awt.image.BufferedImage;
import java.io.IOException;
import org.json.JSONObject;
import com.bananadash.game.utils.BananaAPI;
import java.util.Map;


//Handles the core game logic for Banana Dash.
 
public class GameModel {
    private Player player;
    private DatabaseManager databaseManager;
    private BananaAPI bananaAPI;
    private JSONObject currentPuzzleData;
    private BufferedImage currentPuzzleImage;
    private int timeRemaining;
    private boolean gameActive;
    private long gameStartTime;
    private long lastUpdateTime;
    
    
    //Creates a new GameModel.
   
    public GameModel(Player player, DatabaseManager databaseManager) {
        this.player = player;
        this.databaseManager = databaseManager;
        this.bananaAPI = new BananaAPI();
        this.gameActive = false;
        
        // Connect player to database manager for real-time updates
        player.setDatabaseManager(databaseManager);
    }
    
    
    //Starts a new game level.
    
    public void startLevel() {
        // Set the time limit based on the current level
        timeRemaining = player.getCurrentLevelTimeLimit();
        
        // Fetch a new puzzle
        currentPuzzleData = bananaAPI.getPuzzle(true);
        if (currentPuzzleData != null) {
            currentPuzzleImage = bananaAPI.loadPuzzleImage(currentPuzzleData);
            if (currentPuzzleImage != null) {
                System.out.println("Puzzle image loaded successfully");
                gameActive = true;
                gameStartTime = System.currentTimeMillis();
                lastUpdateTime = gameStartTime;
            } else {
                System.err.println("Failed to load puzzle image");
                gameActive = false;
            }
        } else {
            System.err.println("Failed to fetch puzzle data");
            gameActive = false;
        }
    }
    
    
    //Updates the game state, particularly the timer.
    
    public boolean update() {
        if (!gameActive) {
            return false;
        }
        
        long currentTime = System.currentTimeMillis();
        long elapsedTime = (currentTime - lastUpdateTime) / 1000; // Convert to seconds
        
        if (elapsedTime >= 1) {
            timeRemaining -= elapsedTime;
            lastUpdateTime = currentTime;
            
            if (timeRemaining <= 0) {
                timeRemaining = 0;
                gameActive = false;
                return false;
            }
        }
        
        return true;
    }
    
   
    //Validates the player's answer.
    
    public boolean validateAnswer(int userAnswer) {
        if (gameActive && currentPuzzleData != null) {
            boolean isCorrect = bananaAPI.validateAnswer(userAnswer, currentPuzzleData);
            
            if (isCorrect) {
                // Calculate score based on time remaining
                int score = player.calculateScore(timeRemaining);
                
                // Calculate time taken
                long totalTimeInSeconds = (System.currentTimeMillis() - gameStartTime) / 1000;
                
                // Save progress to database
                databaseManager.updateUserProgress(
                    player.getUserId(),
                    player.getCurrentLevel(),
                    score,
                    (int) totalTimeInSeconds
                );
                
                // Advance to next level
                player.advanceLevel();
                
                // Force a refresh of the player's data from the database
                Map<String, Object> updatedProfile = databaseManager.getUserProfile(player.getUserId());
                if (updatedProfile != null) {
                    int updatedScore = (int) updatedProfile.get("totalScore");
                    player.setTotalScore(updatedScore);
                }
                
                return true;
            } else {
                player.resetStreak();
                return false;
            }
        }
        return false;
    }
    
    
    //Get hint for the current puzzle.
    
    public String getHint() {
        // Deduct points for using a hint
        int penalty = -50;
        player.calculateScore(penalty);
        
        // Update the database with the penalty
        databaseManager.updateUserProgress(
            player.getUserId(),
            player.getCurrentLevel(),
            penalty,
            0
        );
        
        // Force a refresh of the player's data from the database
        Map<String, Object> updatedProfile = databaseManager.getUserProfile(player.getUserId());
        if (updatedProfile != null) {
            int updatedScore = (int) updatedProfile.get("totalScore");
            player.setTotalScore(updatedScore);
        }
        
        // Return a generic hint based on the puzzle type
        return "Look for patterns in the sequence and identify the missing number.";
    }
    
   
    //Ends the current game.
    
    public void endGame() {
        gameActive = false;
    }
    
    // Getters
    
    public BufferedImage getCurrentPuzzleImage() {
        return currentPuzzleImage;
    }
    
    public int getTimeRemaining() {
        return timeRemaining;
    }
    
    public boolean isGameActive() {
        return gameActive;
    }
    
    public Player getPlayer() {
        return player;
    }
} 