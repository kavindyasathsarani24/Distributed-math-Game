package com.bananadash.game.view;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import java.util.Map;
import com.bananadash.game.utils.FontManager;


//The profile screen for the Banana Dash game.
 
public class ProfilePanel extends JPanel {
    private GameFrame parentFrame;
    private JLabel usernameLabel;
    private JLabel displayNameLabel;
    private JLabel levelLabel;
    private JLabel scoreLabel;
    
    
    //Creates a new ProfilePanel.
      
    
    public ProfilePanel(GameFrame parentFrame) {
        this.parentFrame = parentFrame;
        
        // Set up the panel
        setLayout(new BorderLayout());
        setBackground(new Color(102, 51, 0)); // Brown background
        
        // Create title panel
        JPanel titlePanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        titlePanel.setOpaque(false);
        
        // Create title label
        JLabel titleLabel = new JLabel("Profile");
        titleLabel.setFont(FontManager.getTitleFont());
        titleLabel.setForeground(Color.WHITE);
        titlePanel.add(titleLabel);
        
        // Create profile info panel with GridBagLayout for better alignment
        JPanel infoPanel = new JPanel(new GridBagLayout());
        infoPanel.setOpaque(false);
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(10, 10, 10, 10);
        
        // Create and add labels with proper alignment
        JLabel usernameTitleLabel = new JLabel("Username:");
        usernameTitleLabel.setFont(FontManager.getSmallBoldFont());
        usernameTitleLabel.setForeground(Color.WHITE);
        
        JLabel displayNameTitleLabel = new JLabel("Display Name:");
        displayNameTitleLabel.setFont(FontManager.getSmallBoldFont());
        displayNameTitleLabel.setForeground(Color.WHITE);
        
        JLabel levelTitleLabel = new JLabel("Current Level:");
        levelTitleLabel.setFont(FontManager.getSmallBoldFont());
        levelTitleLabel.setForeground(Color.WHITE);
        
        JLabel scoreTitleLabel = new JLabel("Total Score:");
        scoreTitleLabel.setFont(FontManager.getSmallBoldFont());
        scoreTitleLabel.setForeground(Color.WHITE);
        
        usernameLabel = new JLabel("N/A");
        usernameLabel.setFont(FontManager.getNormalFont());
        usernameLabel.setForeground(Color.WHITE);
        
        displayNameLabel = new JLabel("N/A");
        displayNameLabel.setFont(FontManager.getNormalFont());
        displayNameLabel.setForeground(Color.WHITE);
        
        levelLabel = new JLabel("N/A");
        levelLabel.setFont(FontManager.getNormalFont());
        levelLabel.setForeground(Color.WHITE);
        
        scoreLabel = new JLabel("N/A");
        scoreLabel.setFont(FontManager.getNormalFont());
        scoreLabel.setForeground(Color.WHITE);
        
        // Add components to the info panel with GridBagLayout
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.EAST;
        infoPanel.add(usernameTitleLabel, gbc);
        
        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.WEST;
        infoPanel.add(usernameLabel, gbc);
        
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.anchor = GridBagConstraints.EAST;
        infoPanel.add(displayNameTitleLabel, gbc);
        
        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.WEST;
        infoPanel.add(displayNameLabel, gbc);
        
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.anchor = GridBagConstraints.EAST;
        infoPanel.add(levelTitleLabel, gbc);
        
        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.WEST;
        infoPanel.add(levelLabel, gbc);
        
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.anchor = GridBagConstraints.EAST;
        infoPanel.add(scoreTitleLabel, gbc);
        
        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.WEST;
        infoPanel.add(scoreLabel, gbc);
        
        // Create buttons panel
        JPanel buttonsPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        buttonsPanel.setOpaque(false);
        
        // Create back button
        JButton backButton = new JButton("Back");
        backButton.setFont(FontManager.getButtonFont());
        backButton.setBackground(new Color(255, 153, 0)); // Orange button
        backButton.setForeground(new Color(102,51,0));
        backButton.setFocusPainted(false);
        backButton.setBorder(BorderFactory.createRaisedBevelBorder());
        backButton.setPreferredSize(new Dimension(120, 40));
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                parentFrame.showPanel("home");
            }
        });
        
        // Add buttons to panel
        buttonsPanel.add(backButton);
        
        // Add panels to main panel
        add(titlePanel, BorderLayout.NORTH);
        
        // Center the info panel by wrapping it
        JPanel centeringPanel = new JPanel(new GridBagLayout());
        centeringPanel.setOpaque(false);
        centeringPanel.add(infoPanel);
        add(centeringPanel, BorderLayout.CENTER);
        
        add(buttonsPanel, BorderLayout.SOUTH);
    }
    
    
    //Updates the profile information.
     
    
    public void updateProfile(Map<String, Object> profileData) {
        if (profileData != null) {
            usernameLabel.setText((String) profileData.get("username"));
            displayNameLabel.setText((String) profileData.get("displayName"));
            levelLabel.setText(String.valueOf(profileData.get("currentLevel")));
            scoreLabel.setText(String.valueOf(profileData.get("totalScore")));
        }
    }
    
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        
        // Draw background gradient
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        
        int w = getWidth();
        int h = getHeight();
        
        Color color1 = new Color(102, 51, 0);
        Color color2 = new Color(204, 102, 0);
        
        GradientPaint gp = new GradientPaint(0, 0, color1, 0, h, color2);
        g2d.setPaint(gp);
        g2d.fillRect(0, 0, w, h);
    }
}