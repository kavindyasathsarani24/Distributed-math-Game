# Leaderboard MVC Architecture

This document describes the Model-View-Controller (MVC) architecture for the leaderboard functionality in the Banana Dash game.

## Overview

The leaderboard functionality has been implemented using the MVC architectural pattern to separate concerns and improve maintainability:

1. **Model**: Handles data and business logic
2. **View**: Displays the leaderboard to the user
3. **Controller**: Manages interactions between the model and view

## Components

### Model (LeaderboardModel.java)

The `LeaderboardModel` class is responsible for:
- Fetching leaderboard data from the database
- Storing and managing leaderboard data
- Updating player scores and ranks
- Tracking when the leaderboard was last updated

Key methods:
- `fetchLeaderboardData()`: Retrieves the latest leaderboard data
- `updatePlayerScore()`: Updates a player's score and level
- `getPlayerRank()`: Gets a player's current rank

### View (LeaderboardPanel.java)

The `LeaderboardPanel` class is responsible for:
- Displaying the leaderboard data in a table
- Providing a refresh button for manual updates
- Showing when the leaderboard was last updated
- Highlighting the current player in the leaderboard

Key methods:
- `updateLeaderboard()`: Updates the table with new leaderboard data
- `setLastUpdatedTime()`: Updates the "last updated" timestamp
- `highlightPlayer()`: Highlights a specific player in the table

### Controller (LeaderboardController.java)

The `LeaderboardController` class is responsible for:
- Handling user interactions with the view
- Coordinating updates between the model and view
- Managing the current player context

Key methods:
- `refreshLeaderboard()`: Fetches new data and updates the view
- `updateIfNeeded()`: Updates the leaderboard if it hasn't been updated recently
- `updatePlayerScore()`: Updates a player's score and refreshes the view

## Flow of Operations

1. A player finishes a level or game.
2. The game calculates the player's score and checks if they've reached a new highest level.
3. The `LeaderboardModel` updates the player's score and level in the database.
4. The `LeaderboardController` refreshes the leaderboard data.
5. The `LeaderboardPanel` displays the updated leaderboard with the player's new rank.

## Integration with Player Class

The `Player` class has been updated to use the `LeaderboardModel` for real-time leaderboard updates:
- When a player's score changes, the `updateLeaderboardRealtime()` method is called
- This method uses the `LeaderboardModel` to update the player's score and rank

## Integration with GameController

The `GameController` initializes the leaderboard components and manages their lifecycle:
- Creates the `LeaderboardModel` and `LeaderboardController`
- Sets the current player in the `LeaderboardController`
- Triggers leaderboard updates when needed 