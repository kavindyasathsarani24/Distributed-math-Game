package com.bananadash.game.view;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import java.util.Map;


//The leaderboard screen for the Banana Dash game.

 
public class LeaderboardPanel extends JPanel {
    private GameFrame parentFrame;
    private JTable leaderboardTable;
    private DefaultTableModel tableModel;
    private JLabel lastUpdatedLabel;
    private JButton refreshButton;
    private ActionListener refreshListener;
    
    
    //Creates a new LeaderboardPanel.
     
    public LeaderboardPanel(GameFrame parentFrame) {
        this.parentFrame = parentFrame;
        
        // Set up the panel
        setLayout(new BorderLayout());
        setBackground(new Color(102, 51, 0)); // Blue background
        
        // Create title panel
        JPanel titlePanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        titlePanel.setOpaque(false);
        
        // Create title label
        JLabel titleLabel = new JLabel("Leaderboard");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 36));
        titleLabel.setForeground(Color.WHITE);
        titlePanel.add(titleLabel);
        
        // Create table panel
        JPanel tablePanel = new JPanel(new BorderLayout());
        tablePanel.setOpaque(false);
        tablePanel.setBorder(BorderFactory.createEmptyBorder(20, 50, 20, 50));
        
        // Create info panel for last updated time and refresh button
        JPanel infoPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        infoPanel.setOpaque(false);
        
        // Create last updated label
        lastUpdatedLabel = new JLabel("Last updated: Never");
        lastUpdatedLabel.setFont(new Font("Arial", Font.ITALIC, 12));
        lastUpdatedLabel.setForeground(Color.WHITE);
        
        // Create refresh button
        refreshButton = new JButton("Refresh");
        refreshButton.setFont(new Font("Arial", Font.BOLD, 12));
        refreshButton.setBackground(new Color(0, 153, 204));
        refreshButton.setForeground(new Color(102, 51, 0));
        refreshButton.setFocusPainted(false);
        refreshButton.setBorder(BorderFactory.createRaisedBevelBorder());
        refreshButton.setPreferredSize(new Dimension(80, 25));
        refreshButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (refreshListener != null) {
                    refreshListener.actionPerformed(e);
                }
            }
        });
        
        infoPanel.add(lastUpdatedLabel);
        infoPanel.add(Box.createRigidArea(new Dimension(10, 0)));
        infoPanel.add(refreshButton);
        
        // Create table model with column names
        String[] columnNames = {"Rank", "Player", "Score", "Highest Level"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Make table non-editable
            }
        };
        
        // Create table
        leaderboardTable = new JTable(tableModel);
        leaderboardTable.setFillsViewportHeight(true);
        leaderboardTable.setRowHeight(30);
        leaderboardTable.setFont(new Font("Arial", Font.PLAIN, 14));
        leaderboardTable.getTableHeader().setFont(new Font("Arial", Font.BOLD, 14));
        leaderboardTable.getTableHeader().setReorderingAllowed(false);
        leaderboardTable.getTableHeader().setResizingAllowed(false);
        
        // Center align all columns
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);
        for (int i = 0; i < leaderboardTable.getColumnCount(); i++) {
            leaderboardTable.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
        }
        
        // Set column widths
        leaderboardTable.getColumnModel().getColumn(0).setPreferredWidth(50);
        leaderboardTable.getColumnModel().getColumn(1).setPreferredWidth(200);
        leaderboardTable.getColumnModel().getColumn(2).setPreferredWidth(100);
        leaderboardTable.getColumnModel().getColumn(3).setPreferredWidth(100);
        
        // Add table to a scroll pane
        JScrollPane scrollPane = new JScrollPane(leaderboardTable);
        scrollPane.setOpaque(false);
        scrollPane.getViewport().setOpaque(false);
        
        tablePanel.add(infoPanel, BorderLayout.NORTH);
        tablePanel.add(scrollPane, BorderLayout.CENTER);
        
        // Create button panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        buttonPanel.setOpaque(false);
        
        // Create back button
        JButton backButton = new JButton("Back to Home");
        backButton.setFont(new Font("Arial", Font.BOLD, 16));
        backButton.setBackground(new Color(255, 153, 0)); // Orange button
        backButton.setForeground(new Color(102, 51, 0));
        backButton.setFocusPainted(false);
        backButton.setBorder(BorderFactory.createRaisedBevelBorder());
        backButton.setPreferredSize(new Dimension(150, 40));
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                parentFrame.showPanel("home");
            }
        });
        buttonPanel.add(backButton);
        
        // Add components to the main panel
        add(titlePanel, BorderLayout.NORTH);
        add(tablePanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
    }
    
    
    //Sets the refresh button listener.
    
    public void setRefreshButtonListener(ActionListener listener) {
        this.refreshListener = listener;
    }
    
    //Updates the leaderboard with the provided data.
     
    public void updateLeaderboard(List<Map<String, Object>> leaderboardData) {
        // Clear existing data
        tableModel.setRowCount(0);
        
        // Add new data
        if (leaderboardData != null) {
            int rank = 1;
            for (Map<String, Object> entry : leaderboardData) {
                String displayName = (String) entry.get("displayName");
                int totalScore = (int) entry.get("totalScore");
                int highestLevel = (int) entry.get("highestLevel");
                
                Object[] rowData = {rank++, displayName, totalScore, highestLevel};
                tableModel.addRow(rowData);
            }
        }
    }
    
    //Sets the last updated time text.
     
    public void setLastUpdatedTime(String timeText) {
        lastUpdatedLabel.setText("Last updated: " + timeText);
    }
    
   //Highlights a specific player in the leaderboard.
    
    public void highlightPlayer(String playerName) {
        if (playerName == null || playerName.isEmpty()) {
            return;
        }
        
        // Find the player in the table
        for (int i = 0; i < tableModel.getRowCount(); i++) {
            String name = (String) tableModel.getValueAt(i, 1);
            if (playerName.equals(name)) {
                // Select the row
                leaderboardTable.setRowSelectionInterval(i, i);
                // Scroll to the row
                leaderboardTable.scrollRectToVisible(leaderboardTable.getCellRect(i, 0, true));
                return;
            }
        }
    }
    
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        
        // Draw a gradient background
        Graphics2D g2d = (Graphics2D) g;
        GradientPaint gradient = new GradientPaint(
            0, 0, new Color(102, 51, 0),
            0, getHeight(), new Color(204, 102, 0)
        );
        g2d.setPaint(gradient);
        g2d.fillRect(0, 0, getWidth(), getHeight());
    }
} 